'use strict';

const { getPool, sql }                                  = require('../db/procurement');
const { createNotification, getAdminUserIds,
        getSupplierUserId }                             = require('../helpers/notifications');

// GET /api/bids  (admin)
async function getAllBids(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT
                b.BidID AS bidId, b.TenderID AS tenderId, t.Title AS tenderTitle,
                b.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                b.SubmittedDate AS submittedDate, b.GrandTotal AS grandTotal,
                bs.BidStatusName AS status, b.CreatedAt
            FROM Bid b
            JOIN Tender          t  ON b.TenderID   = t.TenderID
            JOIN SupplierProfile sp ON b.SupplierID  = sp.SupplierID
            JOIN BidStatus       bs ON b.BidStatusID = bs.BidStatusID
            ORDER BY b.CreatedAt DESC
        `);

        const bids           = result.recordset;
        const allItemsResult = await pool.request().query(`
            SELECT BidID AS bidId, ItemNo AS itemNo, TenderItemID AS tenderItemId,
                   Description, Unit, Quantity, UnitPrice, Total
            FROM BidItem ORDER BY BidID, ItemNo, TenderItemID ASC
        `);

        const itemMap = {};
        allItemsResult.recordset.forEach(row => {
            if (!itemMap[row.BidID]) itemMap[row.BidID] = [];
            itemMap[row.BidID].push(row);
        });
        bids.forEach(bid => { bid.items = itemMap[bid.bidId] || []; });

        res.json(bids);
    } catch (error) {
        console.error('[GET /api/bids] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/bids/:bidId  (auth)
async function getBidById(req, res) {
    const { bidId } = req.params;
    const { userId, role } = req.user;

    try {
        const pool            = await getPool();
        const userSupplierId  = role === 'supplier' ? userId : null;

        let query = `
            SELECT
                b.BidID AS bidId, b.TenderID AS tenderId, t.Title AS tenderTitle,
                b.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                b.SubmittedDate AS submittedDate, b.GrandTotal AS grandTotal,
                bs.BidStatusName AS status, b.ComplianceScore, b.EvaluationScore, b.CreatedAt
            FROM Bid b
            JOIN Tender t ON b.TenderID = t.TenderID
            JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
            JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
            WHERE b.BidID = @bidId
        `;
        if (role === 'supplier') query += ` AND b.SupplierID = @supplierId`;

        const result = await pool.request()
            .input('bidId',      sql.VarChar(50), bidId)
            .input('supplierId', sql.VarChar(50), userSupplierId)
            .query(query);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Bid not found or access denied' });

        const bid         = result.recordset[0];
        const itemsResult = await pool.request()
            .input('bidId', sql.VarChar(50), bidId)
            .query(`
                SELECT ItemNo AS itemNo, TenderItemID AS tenderItemId,
                       Description AS description, Unit AS unit,
                       Quantity AS quantity, UnitPrice AS unitPrice, Total AS total
                FROM BidItem WHERE BidID = @bidId ORDER BY ItemNo ASC
            `);

        bid.items = itemsResult.recordset;
        res.json(bid);
    } catch (error) {
        console.error('[GET /api/bids/:bidId] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/bids/tender/:tenderId  (admin)
async function getBidsByTender(req, res) {
    const { tenderId } = req.params;
    try {
        const pool       = await getPool();
        const bidsResult = await pool.request()
            .input('tenderId', sql.VarChar(50), tenderId)
            .query(`
                SELECT
                    b.BidID AS bidId, b.TenderID AS tenderId,
                    b.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                    b.SubmittedDate AS submittedDate, b.GrandTotal AS grandTotal,
                    bs.BidStatusName AS status, b.ComplianceScore, b.EvaluationScore, b.CreatedAt
                FROM Bid b
                JOIN SupplierProfile sp ON b.SupplierID  = sp.SupplierID
                JOIN BidStatus       bs ON b.BidStatusID = bs.BidStatusID
                WHERE b.TenderID = @tenderId ORDER BY b.SubmittedDate DESC
            `);

        const bids = bidsResult.recordset;
        if (bids.length > 0) {
            const bidIds         = bids.map(b => `'${b.bidId}'`).join(',');
            const allItemsResult = await pool.request().query(`
                SELECT BidID AS bidId, ItemNo AS itemNo, TenderItemID AS tenderItemId,
                       Description, Unit, Quantity, UnitPrice, Total
                FROM BidItem WHERE BidID IN (${bidIds}) ORDER BY BidID, ItemNo, TenderItemID ASC
            `);
            const itemMap = {};
            allItemsResult.recordset.forEach(row => {
                if (!itemMap[row.BidID]) itemMap[row.BidID] = [];
                itemMap[row.BidID].push(row);
            });
            bids.forEach(bid => { bid.items = itemMap[bid.bidId] || []; });
        }
        res.json(bids);
    } catch (error) {
        console.error('[GET /api/bids/tender/:tenderId] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/bids/supplier/:supplierId  (auth)
async function getBidsBySupplier(req, res) {
    const { supplierId } = req.params;
    try {
        const pool       = await getPool();
        const bidsResult = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`
                SELECT
                    b.BidID AS bidId, b.TenderID AS tenderId, t.Title AS tenderTitle,
                    b.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                    b.SubmittedDate AS submittedDate, b.GrandTotal AS grandTotal,
                    bs.BidStatusName AS status, b.ComplianceScore, b.EvaluationScore, b.CreatedAt
                FROM Bid b
                JOIN Tender t ON b.TenderID = t.TenderID
                JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
                JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
                WHERE b.SupplierID = @supplierId ORDER BY b.SubmittedDate DESC
            `);

        const bids = bidsResult.recordset;
        if (bids.length > 0) {
            const bidIds         = bids.map(b => `'${b.bidId}'`).join(',');
            const allItemsResult = await pool.request().query(`
                SELECT BidID AS bidId, ItemNo AS itemNo, TenderItemID AS tenderItemId,
                       Description, Unit, Quantity, UnitPrice, Total
                FROM BidItem WHERE BidID IN (${bidIds}) ORDER BY BidID, ItemNo ASC
            `);
            const itemMap = {};
            allItemsResult.recordset.forEach(row => {
                if (!itemMap[row.bidId]) itemMap[row.bidId] = [];
                itemMap[row.bidId].push({
                    itemNo: row.itemNo, tenderItemId: row.tenderItemId,
                    description: row.Description, unit: row.Unit,
                    quantity: row.Quantity, unitPrice: row.UnitPrice, total: row.Total,
                });
            });
            bids.forEach(bid => { bid.items = itemMap[bid.bidId] || []; });
        }
        res.json(bids);
    } catch (error) {
        console.error('[GET /api/bids/supplier/:supplierId] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// POST /api/bids  (auth)
async function submitBid(req, res) {
    const { bidId, tenderId, supplierId, grandTotal, submittedDate, items } = req.body;

    if (!bidId || !tenderId || !supplierId)
        return res.status(400).json({ message: 'bidId, tenderId, and supplierId are required' });

    try {
        const pool = await getPool();

        const interestCheck = await pool.request()
            .input('tenderId',   sql.VarChar(50), tenderId)
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT 1 FROM Interests WHERE TenderID = @tenderId AND SupplierID = @supplierId`);

        if (interestCheck.recordset.length === 0)
            return res.status(403).json({ message: 'You must express interest in this tender before submitting a bid' });

        const existingBid = await pool.request()
            .input('tenderId',   sql.VarChar(50), tenderId)
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT BidID FROM Bid WHERE TenderID = @tenderId AND SupplierID = @supplierId`);

        if (existingBid.recordset.length > 0)
            return res.status(400).json({ message: 'You have already submitted a bid for this tender' });

        const tenderInfo   = await pool.request().input('tenderId', sql.VarChar(50), tenderId).query(`SELECT Title FROM Tender WHERE TenderID = @tenderId`);
        const supplierInfo = await pool.request().input('supplierId', sql.VarChar(50), supplierId).query(`SELECT CompanyName FROM SupplierProfile WHERE SupplierID = @supplierId`);

        const tenderTitle = tenderInfo.recordset[0]?.Title        || 'a tender';
        const companyName = supplierInfo.recordset[0]?.CompanyName || 'A supplier';

        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('bidId',         sql.VarChar(50),   bidId)
                .input('tenderId',      sql.VarChar(50),   tenderId)
                .input('supplierId',    sql.VarChar(50),   supplierId)
                .input('submittedDate', sql.Date,          submittedDate || new Date().toISOString().split('T')[0])
                .input('grandTotal',    sql.Decimal(18, 2), grandTotal || 0)
                .input('bidStatusId',   sql.VarChar(20),   'BS001')
                .query(`
                    INSERT INTO Bid (BidID, TenderID, SupplierID, SubmittedDate, GrandTotal, BidStatusID, CreatedAt)
                    VALUES (@bidId, @tenderId, @supplierId, @submittedDate, @grandTotal, @bidStatusId, GETDATE())
                `);

            if (items && items.length > 0) {
                for (const item of items) {
                    await transaction.request()
                        .input('bidId',        sql.VarChar(50),       bidId)
                        .input('itemNo',       sql.Int,               item.itemNo)
                        .input('description',  sql.NVarChar(sql.MAX), item.description || '')
                        .input('unit',         sql.NVarChar(50),      item.unit || '')
                        .input('quantity',     sql.Decimal(18, 2),    item.quantity  || 0)
                        .input('unitPrice',    sql.Decimal(18, 2),    item.unitPrice || 0)
                        .input('total',        sql.Decimal(18, 2),    item.total     || 0)
                        .input('tenderItemId', sql.VarChar(50),       item.tenderItemId || '')
                        .query(`
                            INSERT INTO BidItem
                                (BidID, ItemNo, Description, Unit, Quantity, UnitPrice, Total, CreatedAt, TenderItemID)
                            VALUES
                                (@bidId, @itemNo, @description, @unit, @quantity, @unitPrice, @total, GETDATE(), @tenderItemId)
                        `);
                }
            }

            await transaction.commit();

            const adminIds = await getAdminUserIds(pool);
            for (const adminUserId of adminIds) {
                await createNotification(pool, {
                    userId:   adminUserId,
                    userType: 'admin',
                    message:  `${companyName} submitted a bid for "${tenderTitle}".`,
                    type:     'info',
                    link:     `/admin/tenders/${tenderId}`,
                });
            }

            res.status(201).json({ message: 'Bid submitted successfully', bid: { bidId, tenderId, supplierId, grandTotal } });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[POST /api/bids] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// PATCH /api/bids/:id/status  (admin)
async function updateBidStatus(req, res) {
    const { id }           = req.params;
    const { status, note } = req.body;

    const bidStatusMap = { Awarded: 'BS002', Rejected: 'BS003' };
    const bidStatusId  = bidStatusMap[status];
    if (!bidStatusId) return res.status(400).json({ message: 'Invalid status' });

    try {
        const pool      = await getPool();
        const bidResult = await pool.request()
            .input('bidId', sql.VarChar(50), id)
            .query(`
                SELECT b.*, t.Title AS tenderTitle, sp.CompanyName AS supplierName
                FROM Bid b
                JOIN Tender          t  ON b.TenderID   = t.TenderID
                JOIN SupplierProfile sp ON b.SupplierID  = sp.SupplierID
                WHERE b.BidID = @bidId
            `);

        if (bidResult.recordset.length === 0)
            return res.status(404).json({ message: 'Bid not found' });

        const bid         = bidResult.recordset[0];
        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('bidId',       sql.VarChar(50), id)
                .input('bidStatusId', sql.VarChar(20), bidStatusId)
                .query(`UPDATE Bid SET BidStatusID = @bidStatusId WHERE BidID = @bidId`);

            if (status === 'Awarded') {
                await transaction.request()
                    .input('tenderId',    sql.VarChar(50),       bid.TenderID)
                    .input('supplierId',  sql.VarChar(50),       bid.SupplierID)
                    .input('awardAmount', sql.Decimal(18, 2),    bid.GrandTotal)
                    .input('awardNote',   sql.NVarChar(sql.MAX), note || null)
                    .query(`
                        UPDATE Tender SET
                            TenderStatusID = 'TS004', AwardedTo = @supplierId,
                            AwardAmount = @awardAmount, AwardDate = GETDATE(),
                            AwardNote = @awardNote, UpdatedAt = GETDATE()
                        WHERE TenderID = @tenderId
                    `);
            }

            await transaction.commit();

            const supplierUserId = await getSupplierUserId(pool, bid.SupplierID);
            if (supplierUserId) {
                await createNotification(pool, {
                    userId:  supplierUserId,
                    message: status === 'Awarded'
                        ? `Congratulations! Your bid for "${bid.tenderTitle}" has been awarded.`
                        : `Your bid for "${bid.tenderTitle}" was not successful.`,
                    type: status === 'Awarded' ? 'success' : 'error',
                    link: '/supplier/bids',
                });
            }

            res.json({ message: `Bid ${status.toLowerCase()} successfully`, bid: { id, status } });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[PATCH /api/bids/:id/status] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/bids/:bidId/download  — PDF receipt
async function downloadBidPDF(req, res) {
    const { bidId } = req.params;
    const { userId, role } = req.user;

    try {
        const pool           = await getPool();
        const userSupplierId = role === 'supplier' ? userId : null;

        if (role === 'supplier') {
            const supplierCheck = await pool.request()
                .input('supplierId', sql.VarChar(50), userSupplierId)
                .query(`SELECT SupplierID FROM SupplierProfile WHERE SupplierID = @supplierId`);
            if (supplierCheck.recordset.length === 0)
                return res.status(403).json({ message: 'Supplier profile not found' });
        }

        let query = `
            SELECT b.BidID, b.SubmittedDate, b.GrandTotal, bs.BidStatusName AS Status,
                   t.TenderID, t.Title, t.Description AS TenderDescription,
                   t.ClosingDate, t.EstimatedBudget, t.CategoryID,
                   tc.TenderCategoryName AS CategoryName,
                   sp.CompanyName, sp.RegistrationNumber, sp.ContactPerson,
                   sp.Email, sp.Phone, sp.Address
            FROM Bid b
            JOIN Tender t ON b.TenderID = t.TenderID
            JOIN TenderCategory tc ON t.CategoryID = tc.TenderCategoryID
            JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
            JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
            WHERE b.BidID = @bidId
        `;
        if (role === 'supplier') query += ` AND b.SupplierID = @supplierId`;

        const result = await pool.request()
            .input('bidId',      sql.VarChar(50), bidId)
            .input('supplierId', sql.VarChar(50), userSupplierId)
            .query(query);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Bid not found or access denied' });

        const bid         = result.recordset[0];
        const itemsResult = await pool.request()
            .input('bidId', sql.VarChar(50), bidId)
            .query(`SELECT ItemNo, TenderItemID, Description, Unit, Quantity, UnitPrice, Total FROM BidItem WHERE BidID = @bidId ORDER BY ItemNo ASC`);

        const items = itemsResult.recordset;

        const PDFDocument = require('pdfkit');
        const doc = new PDFDocument({ margin: 50, size: 'A4' });

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="Bid_${bidId}_Receipt.pdf"`);
        doc.pipe(res);

        doc.fontSize(20).font('Helvetica-Bold').text('BID CONFIRMATION RECEIPT', { align: 'center' });
        doc.moveDown();
        doc.fontSize(10).font('Helvetica').text(`Generated: ${new Date().toLocaleString()}`, { align: 'center' });
        doc.moveDown(2);

        doc.rect(50, doc.y, 495, 60).stroke();
        doc.fontSize(10).font('Helvetica-Bold').text('BID REFERENCE:', 60, doc.y + 10);
        doc.font('Helvetica').text(bid.BidID, 60, doc.y + 25);
        doc.font('Helvetica-Bold').text('SUBMITTED DATE:', 300, doc.y + 10);
        doc.font('Helvetica').text(new Date(bid.SubmittedDate).toLocaleString(), 300, doc.y + 25);
        doc.font('Helvetica-Bold').text('STATUS:', 60, doc.y + 40);
        const statusColor = bid.Status === 'Awarded' ? 'green' : (bid.Status === 'Rejected' ? 'red' : 'orange');
        doc.fillColor(statusColor).text(bid.Status, 120, doc.y + 40).fillColor('black');
        doc.moveDown(3);

        doc.fontSize(14).font('Helvetica-Bold').text('TENDER DETAILS', { underline: true });
        doc.moveDown(0.5);
        doc.fontSize(10).font('Helvetica');
        const tenderStartY = doc.y;
        doc.text(`Tender ID:`, 50, tenderStartY);        doc.text(bid.TenderID, 150, tenderStartY);
        doc.text(`Category:`,  300, tenderStartY);        doc.text(bid.CategoryName, 380, tenderStartY);
        doc.text(`Title:`,      50, tenderStartY + 20);   doc.text(bid.Title, 150, tenderStartY + 20);
        doc.text(`Closing Date:`, 50, tenderStartY + 40); doc.text(new Date(bid.ClosingDate).toLocaleDateString(), 150, tenderStartY + 40);
        doc.text(`Estimated Budget:`, 300, tenderStartY + 40); doc.text(`GHS ${parseFloat(bid.EstimatedBudget).toFixed(2)}`, 430, tenderStartY + 40);
        doc.moveDown(4);

        doc.fontSize(14).font('Helvetica-Bold').text('SUPPLIER DETAILS', { underline: true });
        doc.moveDown(0.5);
        doc.fontSize(10).font('Helvetica');
        const supplierStartY = doc.y;
        doc.text(`Company Name:`,   50, supplierStartY);        doc.text(bid.CompanyName, 160, supplierStartY);
        doc.text(`Reg Number:`,    300, supplierStartY);        doc.text(bid.RegistrationNumber, 400, supplierStartY);
        doc.text(`Contact Person:`, 50, supplierStartY + 20);   doc.text(bid.ContactPerson, 160, supplierStartY + 20);
        doc.text(`Email:`,         300, supplierStartY + 20);   doc.text(bid.Email, 350, supplierStartY + 20);
        doc.text(`Phone:`,          50, supplierStartY + 40);   doc.text(bid.Phone || '—', 100, supplierStartY + 40);
        doc.text(`Address:`,       300, supplierStartY + 40);   doc.text(bid.Address || '—', 360, supplierStartY + 40);
        doc.moveDown(4);

        doc.fontSize(14).font('Helvetica-Bold').text('BID ITEMS', { underline: true });
        doc.moveDown(0.5);
        const tableTop     = doc.y;
        const colPositions = [50, 130, 220, 280, 330, 380, 450];

        doc.fontSize(9).font('Helvetica-Bold');
        doc.text('Item #',     colPositions[0], tableTop);
        doc.text('Item Code',  colPositions[1], tableTop);
        doc.text('Description',colPositions[2], tableTop);
        doc.text('Unit',       colPositions[3], tableTop);
        doc.text('Quantity',   colPositions[4], tableTop, { width: 50, align: 'right' });
        doc.text('Unit Price', colPositions[5], tableTop, { width: 60, align: 'right' });
        doc.text('Total',      colPositions[6], tableTop, { width: 60, align: 'right' });
        doc.moveTo(50, tableTop + 15).lineTo(545, tableTop + 15).stroke();

        let currentY = tableTop + 25;
        doc.fontSize(9).font('Helvetica');
        items.forEach(item => {
            if (currentY > 700) { doc.addPage(); currentY = 50; }
            doc.text(item.ItemNo.toString(),                  colPositions[0], currentY);
            doc.text(item.TenderItemID,                       colPositions[1], currentY, { width: 80 });
            doc.text(item.Description.substring(0, 40),       colPositions[2], currentY, { width: 100 });
            doc.text(item.Unit,                               colPositions[3], currentY);
            doc.text(item.Quantity.toString(),                colPositions[4], currentY, { width: 50, align: 'right' });
            doc.text(`GHS ${parseFloat(item.UnitPrice).toFixed(2)}`, colPositions[5], currentY, { width: 60, align: 'right' });
            doc.text(`GHS ${parseFloat(item.Total).toFixed(2)}`,     colPositions[6], currentY, { width: 60, align: 'right' });
            currentY += 20;
        });

        currentY += 10;
        doc.moveTo(350, currentY - 5).lineTo(545, currentY - 5).stroke();
        doc.fontSize(12).font('Helvetica-Bold');
        doc.text('GRAND TOTAL:', 350, currentY);
        doc.text(`GHS ${parseFloat(bid.GrandTotal).toFixed(2)}`, 450, currentY, { align: 'right' });
        doc.moveDown(4);
        doc.fontSize(8).font('Helvetica').text('This is a system-generated receipt. Please retain for your records.', 50, 750, { align: 'center' });

        doc.end();
    } catch (error) {
        console.error('[Download Bid PDF] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/bids/supplier/:supplierId/export  — CSV
async function exportBidsCSV(req, res) {
    const { supplierId } = req.params;
    const { userId, role } = req.user;

    try {
        const pool = await getPool();

        if (role === 'supplier' && userId !== supplierId)
            return res.status(403).json({ message: 'You can only export your own bids' });

        const bidsResult = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`
                SELECT b.BidID, b.SubmittedDate, b.GrandTotal, bs.BidStatusName AS Status,
                       t.TenderID, t.Title AS TenderTitle, t.ClosingDate,
                       tc.TenderCategoryName AS Category, sp.CompanyName
                FROM Bid b
                JOIN Tender t ON b.TenderID = t.TenderID
                JOIN TenderCategory tc ON t.CategoryID = tc.TenderCategoryID
                JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
                JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
                WHERE b.SupplierID = @supplierId ORDER BY b.SubmittedDate DESC
            `);

        const bids = bidsResult.recordset;
        for (const bid of bids) {
            const itemsResult = await pool.request()
                .input('bidId', sql.VarChar(50), bid.BidID)
                .query(`SELECT ItemNo, TenderItemID, Description, Unit, Quantity, UnitPrice, Total FROM BidItem WHERE BidID = @bidId ORDER BY ItemNo ASC`);
            bid.Items = itemsResult.recordset;
        }

        const csvData = [];
        for (const bid of bids) {
            if (bid.Items && bid.Items.length > 0) {
                bid.Items.forEach(item => {
                    csvData.push({
                        'Bid ID':          bid.BidID,
                        'Submitted Date':  new Date(bid.SubmittedDate).toLocaleString(),
                        'Status':          bid.Status,
                        'Tender ID':       bid.TenderID,
                        'Tender Title':    bid.TenderTitle,
                        'Category':        bid.Category,
                        'Closing Date':    new Date(bid.ClosingDate).toLocaleDateString(),
                        'Item No':         item.ItemNo,
                        'Item Code':       item.TenderItemID,
                        'Description':     item.Description,
                        'Unit':            item.Unit,
                        'Quantity':        item.Quantity,
                        'Unit Price':      item.UnitPrice,
                        'Item Total':      item.Total,
                        'Bid Grand Total': bid.GrandTotal,
                        'Company':         bid.CompanyName,
                    });
                });
            }
        }

        const { Parser } = require('json2csv');
        const fields = ['Bid ID','Submitted Date','Status','Tender ID','Tender Title','Category','Closing Date','Item No','Item Code','Description','Unit','Quantity','Unit Price','Item Total','Bid Grand Total','Company'];
        const csv    = new Parser({ fields }).parse(csvData);

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="All_Bids_Export_${new Date().toISOString().split('T')[0]}.csv"`);
        res.send(csv);
    } catch (error) {
        console.error('[Export Bids CSV] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

module.exports = {
    getAllBids, getBidById, getBidsByTender, getBidsBySupplier,
    submitBid, updateBidStatus, downloadBidPDF, exportBidsCSV,
};