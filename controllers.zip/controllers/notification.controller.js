'use strict';

const { getPool, sql } = require('../db/procurement');

// GET /api/notifications/:userId
async function getNotifications(req, res) {
    const { userId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('userId', sql.VarChar(50), userId)
            .query(`
                SELECT
                    n.NotificationID AS id, n.Message AS message,
                    nt.NotificationTypeName AS type,
                    n.Timestamp AS timestamp, n.IsRead AS [read], n.Link AS link
                FROM Notifications n
                JOIN NotificationType nt ON n.NotificationTypeID = nt.NotificationTypeID
                WHERE n.UserID = @userId ORDER BY n.Timestamp DESC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET notifications] Error:', error);
        res.json([]);
    }
}

// PATCH /api/notifications/:id/read
async function markAsRead(req, res) {
    const { id } = req.params;
    try {
        const pool = await getPool();
        await pool.request()
            .input('notificationId', sql.VarChar(50), id)
            .query(`UPDATE Notifications SET IsRead = 1 WHERE NotificationID = @notificationId`);
        res.json({ message: 'Notification marked as read' });
    } catch (error) {
        console.error('[PATCH notification read] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

module.exports = { getNotifications, markAsRead };