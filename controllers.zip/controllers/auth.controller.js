'use strict';

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { getPool, sql } = require('../db/procurement');

// ── Admin Login ──────────────────────────────────────────────────────────────

async function adminLogin(req, res) {
    const { email, password } = req.body;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('email', sql.VarChar(255), email)
            .input('role',  sql.VarChar(20),  'admin')
            .query(`
                SELECT
                    su.UserID, su.Email, su.PasswordHash, su.AdminID,
                    ap.Name, ap.Role AS AdminRole,
                    us.UserStatusName AS Status,
                    ISNULL(su.IsFirstLogin, 0) AS IsFirstLogin
                FROM SystemUser su
                JOIN AdminProfiles ap ON su.AdminID      = ap.AdminID
                JOIN UserStatus    us ON su.UserStatusID = us.UserStatusID
                WHERE su.Email = @email AND su.Role = @role
            `);

        if (result.recordset.length === 0)
            return res.status(401).json({ message: 'Invalid credentials' });

        const user = result.recordset[0];

        if (user.Status !== 'Active')
            return res.status(403).json({ message: 'Account is not active' });

        const isValid = await bcrypt.compare(password, user.PasswordHash);
        if (!isValid)
            return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            { userId: user.UserID, adminId: user.AdminID, role: 'admin', email: user.Email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        await pool.request()
            .input('userId', sql.VarChar(50), user.UserID)
            .query(`UPDATE SystemUser SET LastLogin = GETDATE() WHERE UserID = @userId`);

        res.json({
            message: 'Login successful',
            user:    { id: user.UserID, adminId: user.AdminID, name: user.Name, email: user.Email, role: 'admin' },
            token,
            requiresPasswordChange: user.IsFirstLogin === 1 || user.IsFirstLogin === true,
        });
    } catch (error) {
        console.error('[Admin Login] Error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
}

// ── Supplier Login ───────────────────────────────────────────────────────────

async function supplierLogin(req, res) {
    const { email, password } = req.body;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('email', sql.VarChar(255), email)
            .input('role',  sql.VarChar(20),  'supplier')
            .query(`
                SELECT
                    su.UserID, su.Email, su.PasswordHash, su.SupplierID,
                    sp.CompanyName, sp.ContactPerson, sp.ProfileStatusID,
                    ps.ProfileStatusName AS Status,
                    us.UserStatusName    AS UserStatus,
                    ISNULL(su.IsFirstLogin, 1) AS IsFirstLogin
                FROM SystemUser su
                JOIN SupplierProfile sp ON su.SupplierID      = sp.SupplierID
                JOIN ProfileStatus   ps ON sp.ProfileStatusID = ps.ProfileStatusID
                JOIN UserStatus      us ON su.UserStatusID    = us.UserStatusID
                WHERE su.Email = @email AND su.Role = @role
            `);

        if (result.recordset.length === 0)
            return res.status(401).json({ message: 'Invalid credentials' });

        const user = result.recordset[0];

        if (user.UserStatus !== 'Active')
            return res.status(403).json({ message: 'Account is not active' });

        if (user.Status !== 'Approved')
            return res.status(403).json({ message: 'Account not approved yet. Please wait for admin approval.' });

        const isValid = await bcrypt.compare(password, user.PasswordHash);
        if (!isValid)
            return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            { userId: user.SupplierID, role: 'supplier', email: user.Email, companyName: user.CompanyName },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        await pool.request()
            .input('userId', sql.VarChar(50), user.UserID)
            .query(`UPDATE SystemUser SET LastLogin = GETDATE() WHERE UserID = @userId`);

        res.json({
            message: 'Login successful',
            user: {
                id:          user.SupplierID,
                name:        user.ContactPerson || user.CompanyName,
                companyName: user.CompanyName,
                email:       user.Email,
                role:        'supplier',
            },
            token,
            requiresPasswordChange: user.IsFirstLogin === 1 || user.IsFirstLogin === true,
        });
    } catch (error) {
        console.error('[Supplier Login] Error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
}

// ── Change Password (admin + supplier) ──────────────────────────────────────

async function changePassword(req, res) {
    const { currentPassword, newPassword } = req.body;

    if (!newPassword || newPassword.length < 8)
        return res.status(400).json({ message: 'New password must be at least 8 characters' });

    const { role } = req.user;

    try {
        const pool = await getPool();
        let userRow;

        if (role === 'admin') {
            const adminId = req.user.adminId;
            if (!adminId)
                return res.status(400).json({ message: 'Token is missing adminId claim — please log in again' });

            const result = await pool.request()
                .input('adminId', sql.VarChar(50), adminId)
                .query(`SELECT PasswordHash, IsFirstLogin FROM SystemUser WHERE AdminID = @adminId AND Role = 'admin'`);

            if (result.recordset.length === 0)
                return res.status(404).json({ message: 'Admin user not found' });

            userRow = result.recordset[0];
        } else {
            const supplierId = req.user.userId;
            const result     = await pool.request()
                .input('supplierId', sql.VarChar(50), supplierId)
                .query(`SELECT PasswordHash, IsFirstLogin FROM SystemUser WHERE SupplierID = @supplierId AND Role = 'supplier'`);

            if (result.recordset.length === 0)
                return res.status(404).json({ message: 'Supplier user not found' });

            userRow = result.recordset[0];
        }

        const isFirstLogin = userRow.IsFirstLogin === 1 || userRow.IsFirstLogin === true;

        if (!isFirstLogin) {
            if (!currentPassword)
                return res.status(400).json({ message: 'Current password is required' });

            const isValid = await bcrypt.compare(currentPassword, userRow.PasswordHash);
            if (!isValid)
                return res.status(401).json({ message: 'Current password is incorrect' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        if (role === 'admin') {
            await pool.request()
                .input('adminId',      sql.VarChar(50),  req.user.adminId)
                .input('passwordHash', sql.VarChar(255), hashedPassword)
                .query(`UPDATE SystemUser SET PasswordHash = @passwordHash, IsFirstLogin = 0 WHERE AdminID = @adminId AND Role = 'admin'`);
        } else {
            await pool.request()
                .input('supplierId',   sql.VarChar(50),  req.user.userId)
                .input('passwordHash', sql.VarChar(255), hashedPassword)
                .query(`UPDATE SystemUser SET PasswordHash = @passwordHash, IsFirstLogin = 0 WHERE SupplierID = @supplierId AND Role = 'supplier'`);
        }

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('[Change Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// ── Admin-specific Change Password (backwards compat) ───────────────────────

async function adminChangePassword(req, res) {
    const { currentPassword, newPassword } = req.body;
    const adminId = req.user.adminId;

    if (!adminId)
        return res.status(400).json({ message: 'Token is missing adminId — please log in again' });
    if (!newPassword || newPassword.length < 8)
        return res.status(400).json({ message: 'New password must be at least 8 characters' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('adminId', sql.VarChar(50), adminId)
            .query(`SELECT PasswordHash, IsFirstLogin FROM SystemUser WHERE AdminID = @adminId AND Role = 'admin'`);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Admin user not found' });

        const userRow      = result.recordset[0];
        const isFirstLogin = userRow.IsFirstLogin === 1 || userRow.IsFirstLogin === true;

        if (!isFirstLogin) {
            if (!currentPassword)
                return res.status(400).json({ message: 'Current password is required' });

            const isValid = await bcrypt.compare(currentPassword, userRow.PasswordHash);
            if (!isValid)
                return res.status(401).json({ message: 'Current password is incorrect' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await pool.request()
            .input('adminId',      sql.VarChar(50),  adminId)
            .input('passwordHash', sql.VarChar(255), hashedPassword)
            .query(`UPDATE SystemUser SET PasswordHash = @passwordHash, IsFirstLogin = 0 WHERE AdminID = @adminId AND Role = 'admin'`);

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('[Admin Change Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// ── Forgot Password ──────────────────────────────────────────────────────────

async function forgotPassword(req, res) {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email is required' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('email', sql.VarChar(255), email)
            .query(`SELECT UserID, Role FROM SystemUser WHERE Email = @email`);

        if (result.recordset.length === 0)
            return res.json({ message: 'If an account exists for that email, a reset link has been sent' });

        const resetToken  = crypto.randomBytes(32).toString('hex');
        const resetExpiry = new Date();
        resetExpiry.setHours(resetExpiry.getHours() + 1);

        await pool.request()
            .input('email',  sql.VarChar(255),  email)
            .input('token',  sql.NVarChar(255),  resetToken)
            .input('expiry', sql.DateTime,       resetExpiry)
            .query(`UPDATE SystemUser SET PasswordResetToken = @token, PasswordResetExpiry = @expiry WHERE Email = @email`);

        // TODO: send email with reset link in production
        res.json({
            message: 'If an account exists for that email, a reset link has been sent',
            ...(process.env.NODE_ENV !== 'production' && { resetToken }),
        });
    } catch (error) {
        console.error('[Forgot Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// ── Reset Password ───────────────────────────────────────────────────────────

async function resetPassword(req, res) {
    const { token, newPassword } = req.body;

    if (!token || !newPassword)
        return res.status(400).json({ message: 'Token and new password are required' });
    if (newPassword.length < 8)
        return res.status(400).json({ message: 'Password must be at least 8 characters' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('token', sql.NVarChar(255), token)
            .query(`SELECT Email FROM SystemUser WHERE PasswordResetToken = @token AND PasswordResetExpiry > GETDATE()`);

        if (result.recordset.length === 0)
            return res.status(400).json({ message: 'Invalid or expired reset token' });

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        await pool.request()
            .input('email',        sql.VarChar(255), result.recordset[0].Email)
            .input('passwordHash', sql.VarChar(255), hashedPassword)
            .query(`
                UPDATE SystemUser SET
                    PasswordHash        = @passwordHash,
                    PasswordResetToken  = NULL,
                    PasswordResetExpiry = NULL,
                    IsFirstLogin        = 0
                WHERE Email = @email
            `);

        res.json({ message: 'Password reset successfully' });
    } catch (error) {
        console.error('[Reset Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

module.exports = { adminLogin, supplierLogin, changePassword, adminChangePassword, forgotPassword, resetPassword };