'use strict';

const { getPool, sql } = require('../db/procurement');

async function getStats(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT
                (SELECT COUNT(*) FROM Tender WHERE TenderStatusID = 'TS002') AS activeTenders,
                (SELECT COUNT(*) FROM SupplierProfile WHERE ProfileStatusID = 'PS002') AS approvedSuppliers,
                (SELECT COUNT(*) FROM Bid) AS totalBids
        `);
        res.json(result.recordset[0]);
    } catch (error) {
        console.error('[GET /api/stats] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

async function getRegions(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT RegionID AS id, RegionName AS name,
                   ISNULL(Description,'') AS description, ISNULL(KeyPrefix,'') AS keyPrefix
            FROM Regions ORDER BY RegionName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/regions] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

async function getCitiesByRegion(req, res) {
    const { regionId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('regionId', sql.VarChar(20), regionId)
            .query(`
                SELECT CityID AS id, CityName AS name,
                       ISNULL(Description,'') AS description, RegionID AS regionId
                FROM Cities WHERE RegionID = @regionId ORDER BY CityName ASC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/regions/:regionId/cities] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

async function getCities(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT c.CityID AS id, c.CityName AS name,
                   ISNULL(c.Description,'') AS description,
                   c.RegionID AS regionId, r.RegionName AS regionName,
                   ISNULL(r.KeyPrefix,'') AS regionKeyPrefix
            FROM Cities c JOIN Regions r ON c.RegionID = r.RegionID
            ORDER BY c.CityName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/cities] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

async function getCountries(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT CountryID AS id, CountryName AS name,
                   ISNULL(Description,'') AS description, ISNULL(KeyPrefix,'') AS keyPrefix
            FROM Countries ORDER BY CountryName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/countries] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

async function getCompanyTypes(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT CompanyTypeID AS id, CompanyTypeName AS name,
                   ISNULL(Description,'') AS description, ISNULL(KeyPrefix,'') AS keyPrefix
            FROM CompanyType ORDER BY CompanyTypeName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/company-types] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

module.exports = { getStats, getRegions, getCitiesByRegion, getCities, getCountries, getCompanyTypes };