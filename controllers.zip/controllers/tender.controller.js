'use strict';

const { getPool, sql }                          = require('../db/procurement');
const { generateId }                            = require('../utils/generateId');
const { mapTenderStatus }                       = require('../helpers/tenderHelpers');
const { createNotification, getAdminUserIds }   = require('../helpers/notifications');

// GET /api/tenders
async function getAllTenders(req, res) {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT
                t.TenderID AS id, t.Title AS title, t.Description AS description,
                ISNULL(ts.TenderStatusName,'Draft') AS status,
                t.PublishedDate AS publishedDate, t.OpeningDate AS openingDate,
                t.ClosingDate   AS closingDate,   t.EstimatedBudget AS estimatedBudget,
                t.CategoryID    AS categoryId,    ISNULL(tc.TenderCategoryName,'') AS category,
                t.CreatedAt AS createdAt, t.UpdatedAt AS updatedAt
            FROM Tender t
            LEFT JOIN TenderStatus   ts ON t.TenderStatusID = ts.TenderStatusID
            LEFT JOIN TenderCategory tc ON t.CategoryID     = tc.TenderCategoryID
            ORDER BY t.CreatedAt DESC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/tenders] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/tenders/:id
async function getTenderById(req, res) {
    const { id } = req.params;
    try {
        const pool         = await getPool();
        const tenderResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT
                    t.TenderID AS id, t.Title AS title, t.Description AS description,
                    t.TenderStatusID AS tenderStatusId, ts.TenderStatusName AS status,
                    t.PublishedDate AS publishedDate, t.OpeningDate AS openingDate,
                    t.ClosingDate AS closingDate, t.EstimatedBudget AS estimatedBudget,
                    t.CategoryID AS categoryId, tc.TenderCategoryName AS category,
                    t.CreatedAt AS createdAt, t.UpdatedAt AS updatedAt
                FROM Tender t
                LEFT JOIN TenderStatus   ts ON t.TenderStatusID = ts.TenderStatusID
                LEFT JOIN TenderCategory tc ON t.CategoryID     = tc.TenderCategoryID
                WHERE t.TenderID = @tenderId
            `);

        if (tenderResult.recordset.length === 0)
            return res.status(404).json({ message: 'Tender not found' });

        const tender      = tenderResult.recordset[0];
        const itemsResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT ItemNo AS itemNo, TenderItemID AS tenderItemId,
                       Description AS description, Unit AS unit,
                       Quantity AS quantity, EstimatedUnitPrice AS estimatedUnitPrice
                FROM TenderItem WHERE TenderID = @tenderId ORDER BY ItemNo ASC
            `);

        tender.items = itemsResult.recordset;
        res.json(tender);
    } catch (error) {
        console.error('[GET /api/tenders/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// POST /api/tenders
async function createTender(req, res) {
    const { title, categoryId, description, status, openingDate, closingDate, estimatedBudget, items } = req.body;
    const tenderStatusId = mapTenderStatus(status);
    const tenderId       = generateId('T');

    try {
        const pool = await getPool();

        await pool.request()
            .input('tenderId',        sql.VarChar(50),       tenderId)
            .input('title',           sql.NVarChar(255),     title)
            .input('categoryId',      sql.VarChar(20),       categoryId)
            .input('description',     sql.NVarChar(sql.MAX), description || '')
            .input('statusId',        sql.VarChar(20),       tenderStatusId)
            .input('publishedDate',   sql.Date,              new Date().toISOString().split('T')[0])
            .input('openingDate',     sql.Date,              openingDate  || null)
            .input('closingDate',     sql.Date,              closingDate)
            .input('estimatedBudget', sql.Decimal(18, 2),    estimatedBudget || 0)
            .query(`
                INSERT INTO Tender (
                    TenderID, Title, CategoryID, Description, TenderStatusID,
                    PublishedDate, OpeningDate, ClosingDate, EstimatedBudget, CreatedAt, UpdatedAt
                ) VALUES (
                    @tenderId, @title, @categoryId, @description, @statusId,
                    @publishedDate, @openingDate, @closingDate, @estimatedBudget, GETDATE(), GETDATE()
                )
            `);

        if (items && items.length > 0) {
            for (const item of items) {
                await pool.request()
                    .input('tenderId',           sql.VarChar(50),       tenderId)
                    .input('itemNo',             sql.Int,               item.itemNo)
                    .input('description',        sql.NVarChar(sql.MAX), item.description || '')
                    .input('unit',               sql.NVarChar(50),      item.unit || '')
                    .input('quantity',           sql.Decimal(18, 2),    item.quantity || 0)
                    .input('estimatedUnitPrice', sql.Decimal(18, 2),    item.estimatedUnitPrice || 0)
                    .query(`
                        INSERT INTO TenderItem
                            (TenderID, ItemNo, Description, Unit, Quantity, EstimatedUnitPrice, CreatedAt)
                        VALUES
                            (@tenderId, @itemNo, @description, @unit, @quantity, @estimatedUnitPrice, GETDATE())
                    `);
            }
        }

        if (status === 'Open') {
            const interestedSuppliers = await pool.request()
                .input('categoryId', sql.VarChar(20), categoryId)
                .query(`
                    SELECT DISTINCT su.UserID
                    FROM SupplierCategories sc
                    JOIN SystemUser      su ON sc.SupplierID      = su.SupplierID
                    JOIN SupplierProfile sp ON sc.SupplierID      = sp.SupplierID
                    JOIN ProfileStatus   ps ON sp.ProfileStatusID = ps.ProfileStatusID
                    WHERE sc.CategoryID = @categoryId
                      AND su.Role = 'supplier'
                      AND ps.ProfileStatusName = 'Approved'
                `);

            for (const row of interestedSuppliers.recordset) {
                await createNotification(pool, {
                    userId:  row.UserID,
                    message: `A new tender "${title}" has been published in your category.`,
                    type:    'info',
                    link:    `/supplier/tenders/${tenderId}`,
                });
            }
        }

        res.status(201).json({ message: 'Tender created successfully', tender: { id: tenderId, title, categoryId, status, closingDate } });
    } catch (error) {
        console.error('[POST /api/tenders] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// PUT /api/tenders/:id
async function updateTender(req, res) {
    const { id } = req.params;
    const { title, categoryId, description, status, openingDate, closingDate, estimatedBudget, items } = req.body;
    const tenderStatusId = mapTenderStatus(status);

    try {
        const pool = await getPool();

        const prevResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT ts.TenderStatusName AS prevStatus
                FROM Tender t
                JOIN TenderStatus ts ON t.TenderStatusID = ts.TenderStatusID
                WHERE t.TenderID = @tenderId
            `);

        const prevStatus = prevResult.recordset[0]?.prevStatus || null;

        const result = await pool.request()
            .input('tenderId',        sql.VarChar(50),       id)
            .input('title',           sql.NVarChar(255),     title)
            .input('categoryId',      sql.VarChar(20),       categoryId)
            .input('description',     sql.NVarChar(sql.MAX), description || '')
            .input('statusId',        sql.VarChar(20),       tenderStatusId)
            .input('openingDate',     sql.Date,              openingDate  || null)
            .input('closingDate',     sql.Date,              closingDate)
            .input('estimatedBudget', sql.Decimal(18, 2),    estimatedBudget || 0)
            .query(`
                UPDATE Tender SET
                    Title = @title, CategoryID = @categoryId, Description = @description,
                    TenderStatusID = @statusId, OpeningDate = @openingDate,
                    ClosingDate = @closingDate, EstimatedBudget = @estimatedBudget, UpdatedAt = GETDATE()
                WHERE TenderID = @tenderId
            `);

        if (result.rowsAffected[0] === 0)
            return res.status(404).json({ message: 'Tender not found' });

        if (items !== undefined) {
            const existingItems   = await pool.request()
                .input('tenderId', sql.VarChar(50), id)
                .query(`SELECT ItemNo FROM TenderItem WHERE TenderID = @tenderId`);
            const existingItemNos = existingItems.recordset.map(r => r.ItemNo);
            const incomingItemNos = items.map(i => i.itemNo);

            for (const itemNo of existingItemNos.filter(no => !incomingItemNos.includes(no))) {
                await pool.request()
                    .input('tenderId', sql.VarChar(50), id)
                    .input('itemNo',   sql.Int,         itemNo)
                    .query(`DELETE FROM TenderItem WHERE TenderID = @tenderId AND ItemNo = @itemNo`);
            }

            for (const item of items) {
                await pool.request()
                    .input('tenderId',           sql.VarChar(50),       id)
                    .input('itemNo',             sql.Int,               item.itemNo)
                    .input('description',        sql.NVarChar(sql.MAX), item.description || '')
                    .input('unit',               sql.NVarChar(50),      item.unit || '')
                    .input('quantity',           sql.Decimal(18, 2),    item.quantity || 0)
                    .input('estimatedUnitPrice', sql.Decimal(18, 2),    item.estimatedUnitPrice || 0)
                    .query(`
                        IF EXISTS (SELECT 1 FROM TenderItem WHERE TenderID = @tenderId AND ItemNo = @itemNo)
                            UPDATE TenderItem SET
                                Description = @description, Unit = @unit,
                                Quantity = @quantity, EstimatedUnitPrice = @estimatedUnitPrice
                            WHERE TenderID = @tenderId AND ItemNo = @itemNo
                        ELSE
                            INSERT INTO TenderItem
                                (TenderID, ItemNo, Description, Unit, Quantity, EstimatedUnitPrice, CreatedAt)
                            VALUES
                                (@tenderId, @itemNo, @description, @unit, @quantity, @estimatedUnitPrice, GETDATE())
                    `);
            }
        }

        if (status === 'Open' && prevStatus !== 'Open') {
            const interestedSuppliers = await pool.request()
                .input('categoryId', sql.VarChar(20), categoryId)
                .query(`
                    SELECT DISTINCT su.UserID
                    FROM SupplierCategories sc
                    JOIN SystemUser      su ON sc.SupplierID      = su.SupplierID
                    JOIN SupplierProfile sp ON sc.SupplierID      = sp.SupplierID
                    JOIN ProfileStatus   ps ON sp.ProfileStatusID = ps.ProfileStatusID
                    WHERE sc.CategoryID = @categoryId
                      AND su.Role = 'supplier'
                      AND ps.ProfileStatusName = 'Approved'
                `);

            for (const row of interestedSuppliers.recordset) {
                await createNotification(pool, {
                    userId:  row.UserID,
                    message: `Tender "${title}" is now open for bidding.`,
                    type:    'info',
                    link:    `/supplier/tenders/${id}`,
                });
            }
        }

        res.json({ message: 'Tender updated successfully' });
    } catch (error) {
        console.error('[PUT /api/tenders/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// DELETE /api/tenders/:id  (Draft only)
async function deleteTender(req, res) {
    const { id } = req.params;
    try {
        const pool        = await getPool();
        const checkResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT ts.TenderStatusName
                FROM Tender t
                JOIN TenderStatus ts ON t.TenderStatusID = ts.TenderStatusID
                WHERE t.TenderID = @tenderId
            `);

        if (checkResult.recordset.length === 0)
            return res.status(404).json({ message: 'Tender not found' });

        const status = checkResult.recordset[0].TenderStatusName;
        if (status !== 'Draft')
            return res.status(403).json({ message: `Cannot delete a tender with status '${status}'. Only Draft tenders can be deleted.` });

        const result = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`DELETE FROM Tender WHERE TenderID = @tenderId`);

        if (result.rowsAffected[0] === 0)
            return res.status(404).json({ message: 'Tender not found' });

        res.json({ message: 'Tender deleted successfully' });
    } catch (error) {
        console.error('[DELETE /api/tenders/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/tenders/:id/interests
async function getTenderInterests(req, res) {
    const { id } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT i.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                       i.InterestDate AS date
                FROM Interests i
                JOIN SupplierProfile sp ON i.SupplierID = sp.SupplierID
                WHERE i.TenderID = @tenderId ORDER BY i.InterestDate DESC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET tender interests] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

// POST /api/tenders/:id/interest
async function expressInterest(req, res) {
    const { id }         = req.params;
    const { supplierId } = req.body;
    if (!supplierId) return res.status(400).json({ message: 'Supplier ID is required' });

    try {
        const pool     = await getPool();
        const existing = await pool.request()
            .input('tenderId',   sql.VarChar(50), id)
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT * FROM Interests WHERE TenderID = @tenderId AND SupplierID = @supplierId`);

        if (existing.recordset.length > 0)
            return res.json({ message: 'Interest already expressed', alreadyInterested: true });

        await pool.request()
            .input('tenderId',     sql.VarChar(50), id)
            .input('supplierId',   sql.VarChar(50), supplierId)
            .input('interestDate', sql.Date,         new Date().toISOString().split('T')[0])
            .query(`INSERT INTO Interests (TenderID, SupplierID, InterestDate) VALUES (@tenderId, @supplierId, @interestDate)`);

        res.json({ message: 'Interest expressed successfully' });
    } catch (error) {
        console.error('[POST tender interest] Error:', error);
        res.status(500).json({ message: error.message });
    }
}

module.exports = { getAllTenders, getTenderById, createTender, updateTender, deleteTender, getTenderInterests, expressInterest };