// ============================================================
// DEPENDENCIES & STARTUP VALIDATION
// ============================================================

require('dotenv').config();

if (!process.env.JWT_SECRET) {
    console.error('[FATAL] JWT_SECRET is not set in .env. Exiting.');
    process.exit(1);
}

const crypto  = require('crypto');   
const path    = require('path');
const fs      = require('fs-extra');
const express = require('express');
const cors    = require('cors');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const rateLimit         = require('express-rate-limit');
const { getPool, sql }  = require('./db/procurement');
const { upload }        = require('./utils/fileUpload');
const IDGenerator = require('./utils/idGenerator');

const app  = express();
const PORT = process.env.PORT || 5001;


const cron = require('node-cron');

// Runs every day at midnight
cron.schedule('0 0 * * *', async () => {
    try {
      const pool  = await getPool();
      const today = new Date().toISOString().split('T')[0];
      const in3   = new Date(); in3.setDate(new Date().getDate() + 3);
      const in3Str = in3.toISOString().split('T')[0];
 
      // Update statuses
      await pool.request()
        .input('today', sql.Date, today)
        .query(`UPDATE Tender SET TenderStatusID = 'TS002', UpdatedAt = GETDATE()
                WHERE TenderStatusID = 'TS001' AND OpeningDate <= @today AND ClosingDate > @today`);
 
      await pool.request()
        .input('today', sql.Date, today)
        .query(`UPDATE Tender SET TenderStatusID = 'TS003', UpdatedAt = GETDATE()
                WHERE TenderStatusID = 'TS002' AND ClosingDate < @today`);
 
      // Notify about tenders closing in 3 days
      const closingSoon = await pool.request()
        .input('today', sql.Date, today)
        .input('in3',   sql.Date, in3Str)
        .query(`
          SELECT t.TenderID, t.Title, t.ClosingDate
          FROM Tender t
          WHERE t.TenderStatusID = 'TS002'
            AND t.ClosingDate BETWEEN @today AND @in3
        `);
 
      for (const tender of closingSoon.recordset) {
        // Notify suppliers who expressed interest
        const interested = await pool.request()
          .input('tenderId', sql.VarChar(50), tender.TenderID)
          .query(`
            SELECT su.UserID
            FROM Interests i
            JOIN SystemUser su ON i.SupplierID = su.SupplierID
            WHERE i.TenderID = @tenderId AND su.Role = 'supplier'
          `);
 
        for (const row of interested.recordset) {
          await createNotification(pool, {
            userId:  row.UserID,
            message: `Tender "${tender.Title}" closes on ${tender.ClosingDate.toISOString().split('T')[0]}. Don't miss the deadline!`,
            type:    'warning',
            link:    `/supplier/tenders/${tender.TenderID}`,
          });
        }
 
        // Notify all admins
        const adminIds = await getAdminUserIds(pool);
        for (const adminUserId of adminIds) {
          await createNotification(pool, {
            userId:  adminUserId,
            message: `Tender "${tender.Title}" is closing on ${tender.ClosingDate.toISOString().split('T')[0]}.`,
            type:    'warning',
            link:    `/admin/tenders/${tender.TenderID}`,
          });
        }
      }
 
      console.log('[Cron] Tender statuses updated, closing-soon notifications sent');
    } catch (err) {
      console.error('[Cron] Error:', err.message);
    }
});

 


// ============================================================
// HELPERS
// ============================================================


function generateId(prefix) {
    const ts  = Date.now().toString(36);
    const rnd = Math.random().toString(36).slice(2, 6);
    return `${prefix}-${ts}-${rnd}`.toUpperCase();
}

function mapTenderStatus(status) {
    const map = { Draft: 'TS001', Open: 'TS002', Closed: 'TS003', Awarded: 'TS004' };
    return map[status] || 'TS001';
}

async function generateRegistrationNumber(pool) {
    const now       = new Date();
    const yearMonth = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}`;

    const result = await pool.request()
        .input('pattern', sql.VarChar(50), `Reg${yearMonth}%`)
        .query(`
            SELECT TOP 1 RegistrationNumber FROM SupplierProfile
            WHERE RegistrationNumber LIKE @pattern
            ORDER BY RegistrationNumber DESC
        `);

    let nextNumber = 1;
    if (result.recordset.length > 0) {
        const lastSeq = parseInt(result.recordset[0].RegistrationNumber.slice(-5), 10);
        if (!isNaN(lastSeq)) nextNumber = lastSeq + 1;
    }
    return `Reg${yearMonth}${String(nextNumber).padStart(5, '0')}`;
}

const DOCUMENT_CONFIG = {
    companyProfile:             { name: 'Company Profile / Brochure',                  fileName: 'company-profile',          required: false, requiresExpiry: false },
    certificateOfIncorporation: { name: 'Certificate of Incorporation',                fileName: 'certificate-incorporation', required: true,  requiresExpiry: false },
    graClearance:               { name: 'GRA Clearance Certificate',                   fileName: 'gra-clearance',            required: true,  requiresExpiry: true  },
    ssnitClearance:             { name: 'SSNIT Clearance Certificate',                 fileName: 'ssnit-clearance',          required: true,  requiresExpiry: true  },
    fdaCertificate:             { name: 'FDA Certificate',                             fileName: 'fda-certificate',          required: false, requiresExpiry: true  },
    ppaCertificate:             { name: 'PPA Certificate',                             fileName: 'ppa-certificate',          required: false, requiresExpiry: true  },
    introductionLetter:         { name: 'Introduction Letter',                         fileName: 'introduction-letter',      required: true,  requiresExpiry: false },
    auditedFinancials:          { name: 'Audited Financial Statements (past 2 years)', fileName: 'audited-financials',       required: true,  requiresExpiry: false },
    cvDocument:                 { name: 'CV with Past Experiences',                    fileName: 'cv',                       required: true,  requiresExpiry: false },
};


// ============================================================
// NOTIFICATION HELPER
// ============================================================

const NOTIFICATION_TYPES = {
  info:    'NT001',
  success: 'NT002',
  warning: 'NT003',
  error:   'NT004',
};
 
async function createNotification(pool, { userId, message, type = 'info', link = '#', userType = 'system' }) {
  try {
    const notifId     = generateId('NOT');
    const notifTypeId = NOTIFICATION_TYPES[type] || 'NT001';

    await pool.request()
      .input('notifId',   sql.VarChar(50),       notifId)
      .input('userId',    sql.VarChar(50),        userId)
      .input('message',   sql.NVarChar(sql.MAX),  message)
      .input('typeId',    sql.VarChar(20),        notifTypeId)
      .input('link',      sql.NVarChar(255),      link)
      .input('userType',  sql.NVarChar(50),       userType)
      .query(`
        INSERT INTO Notifications
          (NotificationID, UserID, UserType, Message, NotificationTypeID, Timestamp, IsRead, Link)
        VALUES
          (@notifId, @userId, @userType, @message, @typeId, GETDATE(), 0, @link)
      `);
  } catch (err) {
    console.error('[createNotification] Error:', err.message);
  }
}

// fetch all admin UserIDs so we can notify all of them
async function getAdminUserIds(pool) {
  const result = await pool.request()
    .query(`SELECT UserID FROM SystemUser WHERE Role = 'admin'`);
  return result.recordset.map(r => r.UserID);
}
 
// fetch UserID for a supplier by their SupplierID
async function getSupplierUserId(pool, supplierId) {
  const result = await pool.request()
    .input('supplierId', sql.VarChar(50), supplierId)
    .query(`SELECT UserID FROM SystemUser WHERE SupplierID = @supplierId AND Role = 'supplier'`);
  return result.recordset[0]?.UserID || null;
}

// ============================================================
// MIDDLEWARE
// ============================================================

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: { message: 'Too many login attempts. Please try again in 15 minutes.' }
});

function requireAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer '))
        return res.status(401).json({ message: 'Unauthorized: no token provided' });

    const token = authHeader.split(' ')[1];
    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch {
        return res.status(401).json({ message: 'Unauthorized: invalid or expired token' });
    }
}

function requireAdmin(req, res, next) {
    requireAuth(req, res, () => {
        if (req.user.role !== 'admin')
            return res.status(403).json({ message: 'Forbidden: admin access required' });
        next();
    });
}

// Crash guards
process.on('uncaughtException',  (err)    => { console.error('[CRASH] Uncaught Exception:',  err.message, err.stack); });
process.on('unhandledRejection', (reason) => { console.error('[CRASH] Unhandled Rejection:',  reason); });

// GET /api/stats  — public summary stats
app.get('/api/stats', async (req, res) => {
    try {
        const pool = await getPool();
        const result = await pool.request().query(`
            SELECT
                (SELECT COUNT(*) FROM Tender WHERE TenderStatusID = 'TS002') AS activeTenders,
                (SELECT COUNT(*) FROM SupplierProfile WHERE ProfileStatusID = 'PS002') AS approvedSuppliers,
                (SELECT COUNT(*) FROM Bid) AS totalBids
        `);
        res.json(result.recordset[0]);
    } catch (error) {
        console.error('[GET /api/stats] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// HEALTH / DIAGNOSTICS
// ============================================================

app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'Backend running with SQL Server' });
});



// ============================================================
// AUTH — LOGIN
// ============================================================

// POST /api/auth/admin/login
app.post('/api/auth/admin/login', loginLimiter, async (req, res) => {
    const { email, password } = req.body;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('email', sql.VarChar(255), email)
            .input('role',  sql.VarChar(20),  'admin')
            .query(`
                SELECT
                    su.UserID, su.Email, su.PasswordHash, su.AdminID,
                    ap.Name, ap.Role AS AdminRole,
                    us.UserStatusName AS Status,
                    ISNULL(su.IsFirstLogin, 0) AS IsFirstLogin
                FROM SystemUser su
                JOIN AdminProfiles ap ON su.AdminID      = ap.AdminID
                JOIN UserStatus    us ON su.UserStatusID = us.UserStatusID
                WHERE su.Email = @email AND su.Role = @role
            `);

        if (result.recordset.length === 0)
            return res.status(401).json({ message: 'Invalid credentials' });

        const user = result.recordset[0];

        if (user.Status !== 'Active')
            return res.status(403).json({ message: 'Account is not active' });

        const isValid = await bcrypt.compare(password, user.PasswordHash);
        if (!isValid)
            return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            // FIX: store adminId explicitly so change-password can find it
            { userId: user.UserID, adminId: user.AdminID, role: 'admin', email: user.Email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        await pool.request()
            .input('userId', sql.VarChar(50), user.UserID)
            .query(`UPDATE SystemUser SET LastLogin = GETDATE() WHERE UserID = @userId`);

        res.json({
            message: 'Login successful',
            user:    { id: user.UserID, adminId: user.AdminID, name: user.Name, email: user.Email, role: 'admin' },
            token,
            requiresPasswordChange: user.IsFirstLogin === 1 || user.IsFirstLogin === true
        });
    } catch (error) {
        console.error('[Admin Login] Error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// POST /api/auth/supplier/login
app.post('/api/auth/supplier/login', loginLimiter, async (req, res) => {
    const { email, password } = req.body;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('email', sql.VarChar(255), email)
            .input('role',  sql.VarChar(20),  'supplier')
            .query(`
                SELECT
                    su.UserID, su.Email, su.PasswordHash, su.SupplierID,
                    sp.CompanyName, sp.ContactPerson, sp.ProfileStatusID,
                    ps.ProfileStatusName AS Status,
                    us.UserStatusName    AS UserStatus,
                    ISNULL(su.IsFirstLogin, 1) AS IsFirstLogin
                FROM SystemUser su
                JOIN SupplierProfile sp ON su.SupplierID      = sp.SupplierID
                JOIN ProfileStatus   ps ON sp.ProfileStatusID = ps.ProfileStatusID
                JOIN UserStatus      us ON su.UserStatusID    = us.UserStatusID
                WHERE su.Email = @email AND su.Role = @role
            `);

        if (result.recordset.length === 0)
            return res.status(401).json({ message: 'Invalid credentials' });

        const user = result.recordset[0];

        if (user.UserStatus !== 'Active')
            return res.status(403).json({ message: 'Account is not active' });

        if (user.Status !== 'Approved')
            return res.status(403).json({ message: 'Account not approved yet. Please wait for admin approval.' });

        const isValid = await bcrypt.compare(password, user.PasswordHash);
        if (!isValid)
            return res.status(401).json({ message: 'Invalid credentials' });

        // FIX: supplier JWT uses supplierId (not userId) so change-password
        //      can look up by SupplierID — must be consistent with the query below
        const token = jwt.sign(
            { userId: user.SupplierID, role: 'supplier', email: user.Email, companyName: user.CompanyName },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        await pool.request()
            .input('userId', sql.VarChar(50), user.UserID)
            .query(`UPDATE SystemUser SET LastLogin = GETDATE() WHERE UserID = @userId`);

        res.json({
            message: 'Login successful',
            user: {
                id:          user.SupplierID,
                name:        user.ContactPerson || user.CompanyName,
                companyName: user.CompanyName,
                email:       user.Email,
                role:        'supplier'
            },
            token,
            requiresPasswordChange: user.IsFirstLogin === 1 || user.IsFirstLogin === true
        });
    } catch (error) {
        console.error('[Supplier Login] Error:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});


// ============================================================
// AUTH — PASSWORD MANAGEMENT
// ============================================================

/**
 * POST /api/auth/change-password
 * Works for both admins and suppliers.
 *
 * FIX: replaced unsafe string-interpolated WHERE clause with two
 *      explicit parameterised queries — one per role — to avoid
 *      SQL injection and fix the broken admin lookup (the JWT
 *      stores adminId, not userId, as the lookup key for admins).
 */
app.post('/api/auth/change-password', requireAuth, async (req, res) => {
    const { currentPassword, newPassword } = req.body;

    if (!newPassword || newPassword.length < 8)
        return res.status(400).json({ message: 'New password must be at least 8 characters' });

    const { role } = req.user;

    try {
        const pool = await getPool();
        let userRow;

        if (role === 'admin') {
            // FIX: admins are found by AdminID (stored as adminId in the JWT)
            const adminId = req.user.adminId;
            if (!adminId)
                return res.status(400).json({ message: 'Token is missing adminId claim — please log in again' });

            const result = await pool.request()
                .input('adminId', sql.VarChar(50), adminId)
                .query(`
                    SELECT PasswordHash, IsFirstLogin
                    FROM SystemUser
                    WHERE AdminID = @adminId AND Role = 'admin'
                `);

            if (result.recordset.length === 0)
                return res.status(404).json({ message: 'Admin user not found' });

            userRow = result.recordset[0];
        } else {
            // Suppliers are found by SupplierID (stored as userId in the supplier JWT)
            const supplierId = req.user.userId;

            const result = await pool.request()
                .input('supplierId', sql.VarChar(50), supplierId)
                .query(`
                    SELECT PasswordHash, IsFirstLogin
                    FROM SystemUser
                    WHERE SupplierID = @supplierId AND Role = 'supplier'
                `);

            if (result.recordset.length === 0)
                return res.status(404).json({ message: 'Supplier user not found' });

            userRow = result.recordset[0];
        }

        const isFirstLogin = userRow.IsFirstLogin === 1 || userRow.IsFirstLogin === true;

        // Only skip current-password check on a genuine first login
        if (!isFirstLogin) {
            if (!currentPassword)
                return res.status(400).json({ message: 'Current password is required' });

            const isValid = await bcrypt.compare(currentPassword, userRow.PasswordHash);
            if (!isValid)
                return res.status(401).json({ message: 'Current password is incorrect' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        if (role === 'admin') {
            await pool.request()
                .input('adminId',      sql.VarChar(50),  req.user.adminId)
                .input('passwordHash', sql.VarChar(255), hashedPassword)
                .query(`
                    UPDATE SystemUser
                    SET PasswordHash = @passwordHash, IsFirstLogin = 0
                    WHERE AdminID = @adminId AND Role = 'admin'
                `);
        } else {
            await pool.request()
                .input('supplierId',   sql.VarChar(50),  req.user.userId)
                .input('passwordHash', sql.VarChar(255), hashedPassword)
                .query(`
                    UPDATE SystemUser
                    SET PasswordHash = @passwordHash, IsFirstLogin = 0
                    WHERE SupplierID = @supplierId AND Role = 'supplier'
                `);
        }

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('[Change Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

/**
 * POST /api/auth/admin/change-password
 * Kept for backwards compatibility but now delegates to shared logic above.
 * FIX: removed because the generic endpoint above covers it correctly.
 *      Any frontend calls hitting this path should be updated to use
 *      POST /api/auth/change-password instead.
 */
app.post('/api/auth/admin/change-password', requireAdmin, async (req, res) => {
    // Re-use the generic handler — just call next on the shared route
    // by forwarding internally. Simplest: inline the admin branch here.
    const { currentPassword, newPassword } = req.body;
    const adminId = req.user.adminId;

    if (!adminId)
        return res.status(400).json({ message: 'Token is missing adminId — please log in again' });
    if (!newPassword || newPassword.length < 8)
        return res.status(400).json({ message: 'New password must be at least 8 characters' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('adminId', sql.VarChar(50), adminId)
            .query(`
                SELECT PasswordHash, IsFirstLogin
                FROM SystemUser
                WHERE AdminID = @adminId AND Role = 'admin'
            `);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Admin user not found' });

        const userRow      = result.recordset[0];
        const isFirstLogin = userRow.IsFirstLogin === 1 || userRow.IsFirstLogin === true;

        if (!isFirstLogin) {
            if (!currentPassword)
                return res.status(400).json({ message: 'Current password is required' });

            const isValid = await bcrypt.compare(currentPassword, userRow.PasswordHash);
            if (!isValid)
                return res.status(401).json({ message: 'Current password is incorrect' });
        }

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await pool.request()
            .input('adminId',      sql.VarChar(50),  adminId)
            .input('passwordHash', sql.VarChar(255), hashedPassword)
            .query(`
                UPDATE SystemUser
                SET PasswordHash = @passwordHash, IsFirstLogin = 0
                WHERE AdminID = @adminId AND Role = 'admin'
            `);

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('[Admin Change Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// POST /api/auth/forgot-password  — request a reset token
// FIX: crypto is now properly required at the top of the file
app.post('/api/auth/forgot-password', async (req, res) => {
    const { email } = req.body;
    if (!email)
        return res.status(400).json({ message: 'Email is required' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('email', sql.VarChar(255), email)
            .query(`SELECT UserID, Role FROM SystemUser WHERE Email = @email`);

        // Always respond the same way — don't reveal whether the email exists
        if (result.recordset.length === 0)
            return res.json({ message: 'If an account exists for that email, a reset link has been sent' });

        const resetToken  = crypto.randomBytes(32).toString('hex');
        const resetExpiry = new Date();
        resetExpiry.setHours(resetExpiry.getHours() + 1);

        await pool.request()
            .input('email',  sql.VarChar(255), email)
            .input('token',  sql.NVarChar(255), resetToken)
            .input('expiry', sql.DateTime,      resetExpiry)
            .query(`
                UPDATE SystemUser
                SET PasswordResetToken = @token, PasswordResetExpiry = @expiry
                WHERE Email = @email
            `);

        // TODO: send email with reset link containing the token
        // For development only — remove resetToken from response in production
        res.json({
            message: 'If an account exists for that email, a reset link has been sent',
            ...(process.env.NODE_ENV !== 'production' && { resetToken })
        });
    } catch (error) {
        console.error('[Forgot Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// POST /api/auth/reset-password  — consume token and set new password
app.post('/api/auth/reset-password', async (req, res) => {
    const { token, newPassword } = req.body;

    if (!token || !newPassword)
        return res.status(400).json({ message: 'Token and new password are required' });
    if (newPassword.length < 8)
        return res.status(400).json({ message: 'Password must be at least 8 characters' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('token', sql.NVarChar(255), token)
            .query(`
                SELECT Email
                FROM SystemUser
                WHERE PasswordResetToken = @token AND PasswordResetExpiry > GETDATE()
            `);

        if (result.recordset.length === 0)
            return res.status(400).json({ message: 'Invalid or expired reset token' });

        const hashedPassword = await bcrypt.hash(newPassword, 10);

        await pool.request()
            .input('email',        sql.VarChar(255), result.recordset[0].Email)
            .input('passwordHash', sql.VarChar(255), hashedPassword)
            .query(`
                UPDATE SystemUser
                SET PasswordHash        = @passwordHash,
                    PasswordResetToken  = NULL,
                    PasswordResetExpiry = NULL,
                    IsFirstLogin        = 0
                WHERE Email = @email
            `);

        res.json({ message: 'Password reset successfully' });
    } catch (error) {
        console.error('[Reset Password] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// REFERENCE DATA  (public)
// ============================================================

app.get('/api/regions', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT RegionID AS id, RegionName AS name,
                   ISNULL(Description,'') AS description, ISNULL(KeyPrefix,'') AS keyPrefix
            FROM Regions ORDER BY RegionName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/regions] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/regions/:regionId/cities', async (req, res) => {
    const { regionId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('regionId', sql.VarChar(20), regionId)
            .query(`
                SELECT CityID AS id, CityName AS name,
                       ISNULL(Description,'') AS description, RegionID AS regionId
                FROM Cities WHERE RegionID = @regionId ORDER BY CityName ASC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/regions/:regionId/cities] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/cities', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT c.CityID AS id, c.CityName AS name,
                   ISNULL(c.Description,'') AS description,
                   c.RegionID AS regionId, r.RegionName AS regionName,
                   ISNULL(r.KeyPrefix,'') AS regionKeyPrefix
            FROM Cities c JOIN Regions r ON c.RegionID = r.RegionID
            ORDER BY c.CityName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/cities] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/countries', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT CountryID AS id, CountryName AS name,
                   ISNULL(Description,'') AS description, ISNULL(KeyPrefix,'') AS keyPrefix
            FROM Countries ORDER BY CountryName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/countries] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/company-types', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT CompanyTypeID AS id, CompanyTypeName AS name,
                   ISNULL(Description,'') AS description, ISNULL(KeyPrefix,'') AS keyPrefix
            FROM CompanyType ORDER BY CompanyTypeName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/company-types] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// CATEGORIES  (public — active only; /all is admin-protected)
// ============================================================


// GET /api/categories/all - admin only
app.get('/api/categories/all', requireAdmin, async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT 
                TenderCategoryID AS categoryid, 
                TenderCategoryName AS categoryname,
                ISNULL(Description,'') AS description, 
                TenderCategoryStatusID AS statusid
            FROM TenderCategory 
            ORDER BY TenderCategoryName ASC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/categories/all] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/categories', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('statusId', sql.VarChar(10), 'C001')
            .query(`
                SELECT TenderCategoryID AS id, TenderCategoryName AS name,
                       ISNULL(Description,'') AS description
                FROM TenderCategory
                WHERE TenderCategoryStatusID = @statusId
                ORDER BY TenderCategoryName ASC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/categories] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/registration/categories', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('statusId', sql.VarChar(10), 'C001')
            .query(`
                SELECT TenderCategoryID AS id, TenderCategoryName AS name,
                       ISNULL(Description,'') AS description
                FROM TenderCategory
                WHERE TenderCategoryStatusID = @statusId
                ORDER BY TenderCategoryName ASC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/registration/categories] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// CATEGORIES - Admin CRUD
// ============================================================

// POST /api/categories - Create new category (admin only)
app.post('/api/categories', requireAdmin, async (req, res) => {
    const { name, description } = req.body;
    
    if (!name || !name.trim()) {
        return res.status(400).json({ message: 'Category name is required' });
    }
    
    try {
        const pool = await getPool();
        const categoryId = await IDGenerator.generateCategoryId();
        
        // Check if category already exists
        const existing = await pool.request()
            .input('name', sql.NVarChar(100), name.trim())
            .query(`SELECT TenderCategoryID FROM TenderCategory WHERE TenderCategoryName = @name`);
        
        if (existing.recordset.length > 0) {
            return res.status(400).json({ message: 'Category already exists' });
        }
        
        // Remove CreatedAt column - let database handle it or use default
        await pool.request()
            .input('categoryId', sql.VarChar(20), categoryId)
            .input('name', sql.NVarChar(100), name.trim())
            .input('description', sql.NVarChar(sql.MAX), description || '')
            .input('statusId', sql.VarChar(10), 'C001')
            .query(`
                INSERT INTO TenderCategory (TenderCategoryID, TenderCategoryName, Description, TenderCategoryStatusID)
                VALUES (@categoryId, @name, @description, @statusId)
            `);
        
        res.status(201).json({ 
            id: categoryId, 
            categoryid: categoryId,
            name: name.trim(), 
            categoryname: name.trim(),
            description: description || '',
            statusid: 'C001'
        });
    } catch (error) {
        console.error('[POST /api/categories] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// DELETE /api/categories/:id - Deactivate category (admin only)
app.delete('/api/categories/:id', requireAdmin, async (req, res) => {
    const { id } = req.params;
    
    try {
        const pool = await getPool();
        
        // Check if category exists
        const existing = await pool.request()
            .input('categoryId', sql.VarChar(20), id)
            .query(`SELECT TenderCategoryID FROM TenderCategory WHERE TenderCategoryID = @categoryId`);
        
        if (existing.recordset.length === 0) {
            return res.status(404).json({ message: 'Category not found' });
        }
        
        // Check if category is used in any active tenders (not closed)
        const inUse = await pool.request()
            .input('categoryId', sql.VarChar(20), id)
            .query(`
                SELECT COUNT(*) as count 
                FROM Tender 
                WHERE CategoryID = @categoryId 
                AND TenderStatusID != 'TS003'
            `);
        
        if (inUse.recordset[0].count > 0) {
            return res.status(400).json({ message: 'Cannot deactivate category that is used in active tenders' });
        }
        
        // Remove UpdatedAt column
        await pool.request()
            .input('categoryId', sql.VarChar(20), id)
            .query(`UPDATE TenderCategory SET TenderCategoryStatusID = 'C002' WHERE TenderCategoryID = @categoryId`);
        
        res.json({ message: 'Category deactivated successfully' });
    } catch (error) {
        console.error('[DELETE /api/categories/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// POST /api/categories/:id/restore - Restore category (admin only)
app.post('/api/categories/:id/restore', requireAdmin, async (req, res) => {
    const { id } = req.params;
    
    try {
        const pool = await getPool();
        
        // Check if category exists
        const existing = await pool.request()
            .input('categoryId', sql.VarChar(20), id)
            .query(`SELECT TenderCategoryID FROM TenderCategory WHERE TenderCategoryID = @categoryId`);
        
        if (existing.recordset.length === 0) {
            return res.status(404).json({ message: 'Category not found' });
        }
        
        // Remove UpdatedAt column
        await pool.request()
            .input('categoryId', sql.VarChar(20), id)
            .query(`UPDATE TenderCategory SET TenderCategoryStatusID = 'C001' WHERE TenderCategoryID = @categoryId`);
        
        res.json({ message: 'Category restored successfully' });
    } catch (error) {
        console.error('[POST /api/categories/:id/restore] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// ============================================================
// TENDERS
// ============================================================

// GET /api/tenders  — public listing
app.get('/api/tenders', async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT
                t.TenderID AS id, t.Title AS title, t.Description AS description,
                ISNULL(ts.TenderStatusName,'Draft') AS status,
                t.PublishedDate AS publishedDate, t.OpeningDate AS openingDate,
                t.ClosingDate   AS closingDate,   t.EstimatedBudget AS estimatedBudget,
                t.CategoryID    AS categoryId,    ISNULL(tc.TenderCategoryName,'') AS category,
                t.CreatedAt AS createdAt, t.UpdatedAt  AS updatedAt
            FROM Tender t
            LEFT JOIN TenderStatus   ts ON t.TenderStatusID = ts.TenderStatusID
            LEFT JOIN TenderCategory tc ON t.CategoryID     = tc.TenderCategoryID
            ORDER BY t.CreatedAt DESC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/tenders] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// GET /api/tenders/:id  — public
app.get('/api/tenders/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const pool         = await getPool();
        const tenderResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT
                    t.TenderID          AS id,         t.Title            AS title,
                    t.Description       AS description, t.TenderStatusID   AS tenderStatusId,
                    ts.TenderStatusName AS status,      t.PublishedDate    AS publishedDate,
                    t.OpeningDate       AS openingDate, t.ClosingDate      AS closingDate,
                    t.EstimatedBudget   AS estimatedBudget,
                    t.CategoryID        AS categoryId,  tc.TenderCategoryName AS category,
                    t.CreatedAt AS createdAt, t.UpdatedAt   AS updatedAt
                FROM Tender t
                LEFT JOIN TenderStatus   ts ON t.TenderStatusID = ts.TenderStatusID
                LEFT JOIN TenderCategory tc ON t.CategoryID     = tc.TenderCategoryID
                WHERE t.TenderID = @tenderId
            `);

        if (tenderResult.recordset.length === 0)
            return res.status(404).json({ message: 'Tender not found' });

        const tender      = tenderResult.recordset[0];
        const itemsResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT ItemNo AS itemNo, TenderItemID AS tenderItemId, Description AS description,
                       Unit AS unit, Quantity AS quantity,
                       EstimatedUnitPrice AS estimatedUnitPrice
                FROM TenderItem WHERE TenderID = @tenderId ORDER BY ItemNo ASC
            `);

        tender.items = itemsResult.recordset;
        res.json(tender);
    } catch (error) {
        console.error('[GET /api/tenders/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// POST /api/tenders  — admin only
app.post('/api/tenders', requireAdmin, async (req, res) => {
    const { title, categoryId, description, status, openingDate, closingDate, estimatedBudget, items } = req.body;
    const tenderStatusId = mapTenderStatus(status);
    const tenderId       = generateId('T');

    try {
        const pool = await getPool();

        await pool.request()
            .input('tenderId',        sql.VarChar(50),       tenderId)
            .input('title',           sql.NVarChar(255),     title)
            .input('categoryId',      sql.VarChar(20),       categoryId)
            .input('description',     sql.NVarChar(sql.MAX), description || '')
            .input('statusId',        sql.VarChar(20),       tenderStatusId)
            .input('publishedDate',   sql.Date,              new Date().toISOString().split('T')[0])
            .input('openingDate',     sql.Date,              openingDate  || null)
            .input('closingDate',     sql.Date,              closingDate)
            .input('estimatedBudget', sql.Decimal(18,2),     estimatedBudget || 0)
            .query(`
                INSERT INTO Tender (
                    TenderID, Title, CategoryID, Description, TenderStatusID,
                    PublishedDate, OpeningDate, ClosingDate, EstimatedBudget, CreatedAt, UpdatedAt
                ) VALUES (
                    @tenderId, @title, @categoryId, @description, @statusId,
                    @publishedDate, @openingDate, @closingDate, @estimatedBudget, GETDATE(), GETDATE()
                )
            `);

        if (items && items.length > 0) {
            for (const item of items) {
                await pool.request()
                    .input('tenderId',           sql.VarChar(50),       tenderId)
                    .input('itemNo',             sql.Int,               item.itemNo)
                    .input('description',        sql.NVarChar(sql.MAX), item.description || '')
                    .input('unit',               sql.NVarChar(50),      item.unit || '')
                    .input('quantity',           sql.Decimal(18,2),     item.quantity || 0)
                    .input('estimatedUnitPrice', sql.Decimal(18,2),     item.estimatedUnitPrice || 0)
                    .query(`
                        INSERT INTO TenderItem
                            (TenderID, ItemNo, Description, Unit, Quantity, EstimatedUnitPrice, CreatedAt)
                        VALUES
                            (@tenderId, @itemNo, @description, @unit, @quantity, @estimatedUnitPrice, GETDATE())
                    `);
            }
        }

        // Notify approved suppliers in this category when tender is published as Open
        if (status === 'Open') {
            const interestedSuppliers = await pool.request()
                .input('categoryId', sql.VarChar(20), categoryId)
                .query(`
                    SELECT DISTINCT su.UserID
                    FROM SupplierCategories sc
                    JOIN SystemUser      su ON sc.SupplierID      = su.SupplierID
                    JOIN SupplierProfile sp ON sc.SupplierID      = sp.SupplierID
                    JOIN ProfileStatus   ps ON sp.ProfileStatusID = ps.ProfileStatusID
                    WHERE sc.CategoryID = @categoryId
                      AND su.Role = 'supplier'
                      AND ps.ProfileStatusName = 'Approved'
                `);

            for (const row of interestedSuppliers.recordset) {
                await createNotification(pool, {
                    userId:  row.UserID,
                    message: `A new tender "${title}" has been published in your category.`,
                    type:    'info',
                    link:    `/supplier/tenders/${tenderId}`,
                });
            }
        }

        res.status(201).json({ message: 'Tender created successfully', tender: { id: tenderId, title, categoryId, status, closingDate } });
    } catch (error) {
        console.error('[POST /api/tenders] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// PUT /api/tenders/:id  — admin only
app.put('/api/tenders/:id', requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { title, categoryId, description, status, openingDate, closingDate, estimatedBudget, items } = req.body;
    const tenderStatusId = mapTenderStatus(status);

    try {
        const pool = await getPool();

        // Fetch previous status so we only notify when transitioning TO Open
        const prevResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT ts.TenderStatusName AS prevStatus
                FROM Tender t
                JOIN TenderStatus ts ON t.TenderStatusID = ts.TenderStatusID
                WHERE t.TenderID = @tenderId
            `);

        const prevStatus = prevResult.recordset[0]?.prevStatus || null;

        const result = await pool.request()
            .input('tenderId',        sql.VarChar(50),       id)
            .input('title',           sql.NVarChar(255),     title)
            .input('categoryId',      sql.VarChar(20),       categoryId)
            .input('description',     sql.NVarChar(sql.MAX), description || '')
            .input('statusId',        sql.VarChar(20),       tenderStatusId)
            .input('openingDate',     sql.Date,              openingDate  || null)
            .input('closingDate',     sql.Date,              closingDate)
            .input('estimatedBudget', sql.Decimal(18,2),     estimatedBudget || 0)
            .query(`
                UPDATE Tender SET
                    Title           = @title,       CategoryID      = @categoryId,
                    Description     = @description, TenderStatusID  = @statusId,
                    OpeningDate     = @openingDate, ClosingDate     = @closingDate,
                    EstimatedBudget = @estimatedBudget, UpdatedAt   = GETDATE()
                WHERE TenderID = @tenderId
            `);

        if (result.rowsAffected[0] === 0)
            return res.status(404).json({ message: 'Tender not found' });

        if (items !== undefined) {
            const existingItems   = await pool.request()
                .input('tenderId', sql.VarChar(50), id)
                .query(`SELECT ItemNo FROM TenderItem WHERE TenderID = @tenderId`);

            const existingItemNos = existingItems.recordset.map(r => r.ItemNo);
            const incomingItemNos = items.map(i => i.itemNo);

            for (const itemNo of existingItemNos.filter(no => !incomingItemNos.includes(no))) {
                await pool.request()
                    .input('tenderId', sql.VarChar(50), id)
                    .input('itemNo',   sql.Int,         itemNo)
                    .query(`DELETE FROM TenderItem WHERE TenderID = @tenderId AND ItemNo = @itemNo`);
            }

            for (const item of items) {
                await pool.request()
                    .input('tenderId',           sql.VarChar(50),       id)
                    .input('itemNo',             sql.Int,               item.itemNo)
                    .input('description',        sql.NVarChar(sql.MAX), item.description || '')
                    .input('unit',               sql.NVarChar(50),      item.unit || '')
                    .input('quantity',           sql.Decimal(18,2),     item.quantity || 0)
                    .input('estimatedUnitPrice', sql.Decimal(18,2),     item.estimatedUnitPrice || 0)
                    .query(`
                        IF EXISTS (SELECT 1 FROM TenderItem WHERE TenderID = @tenderId AND ItemNo = @itemNo)
                            UPDATE TenderItem SET
                                Description = @description, Unit = @unit,
                                Quantity = @quantity, EstimatedUnitPrice = @estimatedUnitPrice
                            WHERE TenderID = @tenderId AND ItemNo = @itemNo
                        ELSE
                            INSERT INTO TenderItem
                                (TenderID, ItemNo, Description, Unit, Quantity, EstimatedUnitPrice, CreatedAt)
                            VALUES
                                (@tenderId, @itemNo, @description, @unit, @quantity, @estimatedUnitPrice, GETDATE())
                    `);
            }
        }

        // Only notify suppliers when status transitions TO Open (not on every edit)
        if (status === 'Open' && prevStatus !== 'Open') {
            const interestedSuppliers = await pool.request()
                .input('categoryId', sql.VarChar(20), categoryId)
                .query(`
                    SELECT DISTINCT su.UserID
                    FROM SupplierCategories sc
                    JOIN SystemUser      su ON sc.SupplierID      = su.SupplierID
                    JOIN SupplierProfile sp ON sc.SupplierID      = sp.SupplierID
                    JOIN ProfileStatus   ps ON sp.ProfileStatusID = ps.ProfileStatusID
                    WHERE sc.CategoryID = @categoryId
                      AND su.Role = 'supplier'
                      AND ps.ProfileStatusName = 'Approved'
                `);

            for (const row of interestedSuppliers.recordset) {
                await createNotification(pool, {
                    userId:  row.UserID,
                    message: `Tender "${title}" is now open for bidding.`,
                    type:    'info',
                    link:    `/supplier/tenders/${id}`,
                });
            }
        }

        res.json({ message: 'Tender updated successfully' });
    } catch (error) {
        console.error('[PUT /api/tenders/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// DELETE /api/tenders/:id  — admin only (Draft status only)
app.delete('/api/tenders/:id', requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        const pool        = await getPool();
        const checkResult = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT ts.TenderStatusName
                FROM Tender t
                JOIN TenderStatus ts ON t.TenderStatusID = ts.TenderStatusID
                WHERE t.TenderID = @tenderId
            `);

        if (checkResult.recordset.length === 0)
            return res.status(404).json({ message: 'Tender not found' });

        const status = checkResult.recordset[0].TenderStatusName;
        if (status !== 'Draft')
            return res.status(403).json({ message: `Cannot delete a tender with status '${status}'. Only Draft tenders can be deleted.` });

        const result = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`DELETE FROM Tender WHERE TenderID = @tenderId`);

        if (result.rowsAffected[0] === 0)
            return res.status(404).json({ message: 'Tender not found' });

        res.json({ message: 'Tender deleted successfully' });
    } catch (error) {
        console.error('[DELETE /api/tenders/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// TENDER INTERESTS
// ============================================================

app.get('/api/tenders/:id/interests', requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('tenderId', sql.VarChar(50), id)
            .query(`
                SELECT i.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                       i.InterestDate AS date
                FROM Interests i
                JOIN SupplierProfile sp ON i.SupplierID = sp.SupplierID
                WHERE i.TenderID = @tenderId ORDER BY i.InterestDate DESC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET tender interests] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.post('/api/tenders/:id/interest', requireAuth, async (req, res) => {
    const { id }         = req.params;
    const { supplierId } = req.body;
    if (!supplierId) return res.status(400).json({ message: 'Supplier ID is required' });

    try {
        const pool     = await getPool();
        const existing = await pool.request()
            .input('tenderId',   sql.VarChar(50), id)
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT * FROM Interests WHERE TenderID = @tenderId AND SupplierID = @supplierId`);

        if (existing.recordset.length > 0)
            return res.json({ message: 'Interest already expressed', alreadyInterested: true });

        await pool.request()
            .input('tenderId',     sql.VarChar(50), id)
            .input('supplierId',   sql.VarChar(50), supplierId)
            .input('interestDate', sql.Date,         new Date().toISOString().split('T')[0])
            .query(`INSERT INTO Interests (TenderID, SupplierID, InterestDate) VALUES (@tenderId, @supplierId, @interestDate)`);

        res.json({ message: 'Interest expressed successfully' });
    } catch (error) {
        console.error('[POST tender interest] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// SUPPLIERS
// ============================================================


app.get('/api/suppliers/generate-registration-number', async (req, res) => {
    try {
        const pool               = await getPool();
        const registrationNumber = await generateRegistrationNumber(pool);
        res.json({ registrationNumber });
    } catch (error) {
        console.error('[GET generate-registration-number] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// GET /api/suppliers  — admin only
app.get('/api/suppliers', requireAdmin, async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT
                sp.SupplierID AS id, sp.RegistrationNumber AS registrationNumber,
                sp.CompanyName AS companyName, sp.Email AS email, sp.DateApplied AS dateApplied,
                ps.ProfileStatusName AS status, sp.RejectionReason AS rejectionReason,
                sp.ContactPerson AS contactPerson, sp.Phone AS phone, sp.Address AS address,
                ct.CompanyTypeName AS companyType, r.RegionName AS region,
                c.CityName AS city, cnt.CountryName AS country,
                sp.CompanyTypeID, sp.RegionID, sp.CityID, sp.CountryID
            FROM SupplierProfile sp
            LEFT JOIN ProfileStatus ps ON sp.ProfileStatusID = ps.ProfileStatusID
            LEFT JOIN CompanyType   ct ON sp.CompanyTypeID   = ct.CompanyTypeID
            LEFT JOIN Regions        r ON sp.RegionID        = r.RegionID
            LEFT JOIN Cities         c ON sp.CityID          = c.CityID
            LEFT JOIN Countries    cnt ON sp.CountryID       = cnt.CountryID
            ORDER BY sp.CreatedAt DESC
        `);

        const suppliers   = result.recordset;
        const catResult   = await pool.request().query(`
            SELECT sc.SupplierID, tc.TenderCategoryName
            FROM SupplierCategories sc
            JOIN TenderCategory tc ON sc.CategoryID = tc.TenderCategoryID
        `);

        const categoryMap = {};
        catResult.recordset.forEach(row => {
            if (!categoryMap[row.SupplierID]) categoryMap[row.SupplierID] = [];
            categoryMap[row.SupplierID].push(row.TenderCategoryName);
        });
        suppliers.forEach(s => { s.categories = categoryMap[s.id] || []; });

        res.json(suppliers);
    } catch (error) {
        console.error('[GET /api/suppliers] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// GET /api/suppliers/:id  — admin OR the supplier themselves
app.get('/api/suppliers/:id', requireAuth, async (req, res) => {
    const { id } = req.params;

    if (req.user.role !== 'admin' && req.user.userId !== id)
        return res.status(403).json({ message: 'Forbidden: You can only access your own profile' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), id)
            .query(`
                SELECT
                    sp.SupplierID AS id, sp.RegistrationNumber AS registrationNumber,
                    sp.CompanyName AS companyName, sp.TIN AS tin,
                    sp.DateOfIncorporation AS dateOfIncorporation,
                    sp.CountryOfIncorporation AS countryOfIncorporation,
                    sp.ContactPerson AS contactPerson, sp.Designation,
                    sp.Email AS email, sp.Phone AS phone, sp.Address AS address,
                    ps.ProfileStatusName AS status, ps.ProfileStatusID AS statusId,
                    sp.RejectionReason AS rejectionReason, sp.DateApplied AS dateApplied,
                    sp.Documents, sp.Experiences,
                    sp.ExperienceCount AS experienceCount, sp.HasExperiences AS hasExperiences,
                    ct.CompanyTypeID,  ct.CompanyTypeName AS companyTypeName,  ct.KeyPrefix AS companyTypeKeyPrefix,
                     r.RegionID,        r.RegionName AS regionName,             r.KeyPrefix AS regionKeyPrefix,
                     c.CityID,          c.CityName AS cityName,
                   cnt.CountryID,     cnt.CountryName AS countryName,         cnt.KeyPrefix AS countryKeyPrefix
                FROM SupplierProfile sp
                LEFT JOIN ProfileStatus ps ON sp.ProfileStatusID = ps.ProfileStatusID
                LEFT JOIN CompanyType   ct ON sp.CompanyTypeID   = ct.CompanyTypeID
                LEFT JOIN Regions        r ON sp.RegionID        = r.RegionID
                LEFT JOIN Cities         c ON sp.CityID          = c.CityID
                LEFT JOIN Countries    cnt ON sp.CountryID       = cnt.CountryID
                WHERE sp.SupplierID = @supplierId
            `);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Supplier not found' });

        const supplier  = result.recordset[0];
        const catResult = await pool.request()
            .input('supplierId', sql.VarChar(50), id)
            .query(`
                SELECT sc.CategoryID AS id, tc.TenderCategoryName AS name
                FROM SupplierCategories sc
                JOIN TenderCategory tc ON sc.CategoryID = tc.TenderCategoryID
                WHERE sc.SupplierID = @supplierId
            `);

        supplier.categories  = catResult.recordset;
        supplier.documents   = supplier.Documents   ? JSON.parse(supplier.Documents)   : [];
        supplier.experiences = supplier.Experiences ? JSON.parse(supplier.Experiences) : [];
        delete supplier.Documents;
        delete supplier.Experiences;

        supplier.companyType = supplier.CompanyTypeID ? { id: supplier.CompanyTypeID, name: supplier.companyTypeName, keyPrefix: supplier.companyTypeKeyPrefix } : null;
        supplier.region      = supplier.RegionID      ? { id: supplier.RegionID,      name: supplier.regionName,      keyPrefix: supplier.regionKeyPrefix }      : null;
        supplier.city        = supplier.CityID        ? { id: supplier.CityID,        name: supplier.cityName }                                                   : null;
        supplier.country     = supplier.CountryID     ? { id: supplier.CountryID,     name: supplier.countryName,     keyPrefix: supplier.countryKeyPrefix }     : null;

        ['companyTypeName','companyTypeKeyPrefix','regionName','regionKeyPrefix','cityName','countryName','countryKeyPrefix']
            .forEach(k => delete supplier[k]);

        res.json(supplier);
    } catch (error) {
        console.error('[GET /api/suppliers/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// POST /api/suppliers/register  — public registration endpoint
app.post('/api/suppliers/register', async (req, res) => {
    const {
        companyName, tin, dateOfIncorporation, countryOfIncorporation,
        companyTypeId, contactPerson, designation, email, phone, address,
        cityId, regionId, countryId, categories, password
    } = req.body;

    try {
        const pool          = await getPool();
        const existingEmail = await pool.request()
            .input('email', sql.VarChar(255), email)
            .query(`SELECT Email FROM SystemUser WHERE Email = @email`);

        if (existingEmail.recordset.length > 0)
            return res.status(400).json({ message: 'Email already registered' });

        const registrationNumber = await generateRegistrationNumber(pool);
        const supplierId         = generateId('SUP');
        const userId             = generateId('USR');
        const hashedPassword     = await bcrypt.hash(password, 10);

        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('supplierId',             sql.VarChar(50),       supplierId)
                .input('registrationNumber',     sql.VarChar(50),       registrationNumber)
                .input('companyName',            sql.NVarChar(255),     companyName)
                .input('tin',                    sql.VarChar(50),       tin || null)
                .input('dateOfIncorporation',    sql.Date,              dateOfIncorporation || null)
                .input('countryOfIncorporation', sql.NVarChar(100),     countryOfIncorporation || 'Ghana')
                .input('companyTypeId',          sql.VarChar(20),       companyTypeId || null)
                .input('contactPerson',          sql.NVarChar(255),     contactPerson)
                .input('designation',            sql.NVarChar(100),     designation || null)
                .input('email',                  sql.VarChar(255),      email)
                .input('phone',                  sql.VarChar(50),       phone || null)
                .input('address',                sql.NVarChar(sql.MAX), address || null)
                .input('cityId',                 sql.VarChar(20),       cityId || null)
                .input('regionId',               sql.VarChar(20),       regionId || null)
                .input('countryId',              sql.VarChar(20),       countryId || null)
                .input('profileStatusId',        sql.VarChar(20),       'PS001')
                .input('dateApplied',            sql.Date,              new Date().toISOString().split('T')[0])
                .query(`
                    INSERT INTO SupplierProfile (
                        SupplierID, RegistrationNumber, CompanyName, TIN,
                        DateOfIncorporation, CountryOfIncorporation, CompanyTypeID,
                        ContactPerson, Designation, Email, Phone, Address,
                        CityID, RegionID, CountryID, ProfileStatusID, DateApplied,
                        Documents, Experiences, CreatedAt
                    ) VALUES (
                        @supplierId, @registrationNumber, @companyName, @tin,
                        @dateOfIncorporation, @countryOfIncorporation, @companyTypeId,
                        @contactPerson, @designation, @email, @phone, @address,
                        @cityId, @regionId, @countryId, @profileStatusId, @dateApplied,
                        '[]', '[]', GETDATE()
                    )
                `);

            await transaction.request()
                .input('userId',       sql.VarChar(50),  userId)
                .input('email',        sql.VarChar(255), email)
                .input('passwordHash', sql.VarChar(255), hashedPassword)
                .input('role',         sql.VarChar(20),  'supplier')
                .input('supplierId',   sql.VarChar(50),  supplierId)
                .input('userStatusId', sql.VarChar(20),  'UST001')
                .query(`
                    INSERT INTO SystemUser
                        (UserID, Email, PasswordHash, Role, SupplierID, UserStatusID, IsFirstLogin, CreateDate)
                    VALUES
                        (@userId, @email, @passwordHash, @role, @supplierId, @userStatusId, 0, GETDATE())
                `);

            if (categories && categories.length > 0) {
                for (const categoryId of categories) {
                    await transaction.request()
                        .input('supplierId', sql.VarChar(50), supplierId)
                        .input('categoryId', sql.VarChar(20), categoryId)
                        .query(`INSERT INTO SupplierCategories (SupplierID, CategoryID) VALUES (@supplierId, @categoryId)`);
                }
            }

            await transaction.commit();

            // Notify all admins about the new supplier registration
            const adminIds = await getAdminUserIds(pool);
            for (const adminUserId of adminIds) {
                await createNotification(pool, {
                    userId:  adminUserId,
                    userType: 'admin',
                    message: `New supplier registration: ${companyName} is pending approval.`,
                    type:    'info',
                    link:    `/admin/suppliers/${supplierId}`,
                });
            }

            res.status(201).json({
                message: 'Registration successful! Please wait for admin approval.',
                supplierId,
                registrationNumber
            });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[POST /api/suppliers/register] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// PATCH /api/suppliers/:id/status  — admin only
app.patch('/api/suppliers/:id/status', requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { status, rejectionReason } = req.body;

    const statusMap       = { Pending: 'PS001', Approved: 'PS002', Rejected: 'PS003', Blacklisted: 'PS004' };
    const profileStatusId = statusMap[status];
    if (!profileStatusId) return res.status(400).json({ message: 'Invalid status' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId',      sql.VarChar(50),       id)
            .input('profileStatusId', sql.VarChar(20),       profileStatusId)
            .input('rejectionReason', sql.NVarChar(sql.MAX), rejectionReason || null)
            .query(`
                UPDATE SupplierProfile SET
                    ProfileStatusID = @profileStatusId,
                    RejectionReason = @rejectionReason
                WHERE SupplierID = @supplierId
            `);

        if (result.rowsAffected[0] === 0)
            return res.status(404).json({ message: 'Supplier not found' });

        const updated = await pool.request()
            .input('supplierId', sql.VarChar(50), id)
            .query(`
                SELECT sp.SupplierID AS id, sp.RegistrationNumber AS registrationNumber,
                       sp.CompanyName AS companyName, sp.Email AS email, sp.DateApplied AS dateApplied,
                       ps.ProfileStatusName AS status, sp.RejectionReason AS rejectionReason
                FROM SupplierProfile sp
                JOIN ProfileStatus ps ON sp.ProfileStatusID = ps.ProfileStatusID
                WHERE sp.SupplierID = @supplierId
            `);

        // Notify the supplier about their status change
        const supplierUserId = await getSupplierUserId(pool, id);
        if (supplierUserId) {
            if (status === 'Approved') {
                await createNotification(pool, {
                    userId:  supplierUserId,
                    userType: 'supplier',
                    message: 'Your supplier account has been approved. You can now browse and bid on tenders.',
                    type:    'success',
                    link:    '/supplier/dashboard',
                });
            } else if (status === 'Rejected') {
                await createNotification(pool, {
                    userId:  supplierUserId,
                    userType: 'supplier',
                    message: `Your supplier account application was rejected.${rejectionReason ? ' Reason: ' + rejectionReason : ''}`,
                    type:    'error',
                    link:    '/supplier/profile',
                });
            } else if (status === 'Blacklisted') {
                await createNotification(pool, {
                    userId:  supplierUserId,
                    userType: 'supplier',
                    message: 'Your supplier account has been blacklisted. Please contact the administrator.',
                    type:    'error',
                    link:    '#',
                });
            }
        }

        res.json(updated.recordset[0]);
    } catch (error) {
        console.error('[PATCH /api/suppliers/:id/status] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// ============================================================
// SUPPLIER — DOCUMENTS
// ============================================================

app.get('/api/suppliers/:supplierId/documents', requireAuth, async (req, res) => {
    const { supplierId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT Documents FROM SupplierProfile WHERE SupplierID = @supplierId`);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Supplier not found' });

        const documents       = result.recordset[0].Documents ? JSON.parse(result.recordset[0].Documents) : [];
        const activeDocuments = documents.filter(doc => doc.status !== 'Replaced');

        const documentsWithUrls = activeDocuments.map(doc => {
            const fileName = doc.fileName ? doc.fileName.split('/').pop() : null;
            return {
                ...doc,
                downloadUrl: fileName ? `http://localhost:${PORT}/api/suppliers/${supplierId}/documents/${fileName}` : null,
                canRenew: doc.requiresExpiry && ['expired', 'critical', 'warning'].includes(doc.status)
            };
        });

        res.json(documentsWithUrls);
    } catch (error) {
        console.error('[GET supplier documents] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// Serve a document file
app.get('/api/suppliers/:supplierId/documents/:fileName', requireAuth, async (req, res) => {
    const { supplierId, fileName } = req.params;
    try {
        const filePath = path.join(__dirname, 'uploads/suppliers', supplierId, fileName);
        if (!await fs.pathExists(filePath))
            return res.status(404).json({ message: 'File not found' });
        res.sendFile(filePath);
    } catch (error) {
        console.error('[GET document file] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// Upload documents
app.post('/api/suppliers/:supplierId/upload-documents',
    upload.fields(Object.keys(DOCUMENT_CONFIG).map(name => ({ name, maxCount: 1 }))),
    async (req, res) => {
        const supplierId = req.params.supplierId;
        const files      = req.files;

        if (!supplierId) return res.status(400).json({ message: 'Supplier ID is required' });
        if (!files || Object.keys(files).length === 0) return res.status(400).json({ message: 'No files uploaded' });

        try {
            const pool        = await getPool();
            const uploadedDocs = [];

            for (const [key, fileArray] of Object.entries(files)) {
                if (!fileArray || fileArray.length === 0) continue;
                const config = DOCUMENT_CONFIG[key];
                if (!config) continue;

                const file = fileArray[0];
                uploadedDocs.push({
                    name:           config.name,
                    fileName:       `${supplierId}/${file.filename}`,
                    docType:        key,
                    status:         'Pending',
                    uploadDate:     new Date().toISOString().split('T')[0],
                    expiryDate:     req.body[`${key}Expiry`] || null,
                    requiresExpiry: config.requiresExpiry
                });
            }

            const existingResult = await pool.request()
                .input('supplierId', sql.VarChar(50), supplierId)
                .query(`SELECT Documents, CompanyName FROM SupplierProfile WHERE SupplierID = @supplierId`);

            const existingDocs = existingResult.recordset[0]?.Documents
                ? JSON.parse(existingResult.recordset[0].Documents)
                : [];
            const companyName  = existingResult.recordset[0]?.CompanyName || 'A supplier';
            const mergedDocs   = [...existingDocs, ...uploadedDocs];

            await pool.request()
                .input('supplierId', sql.VarChar(50),       supplierId)
                .input('documents',  sql.NVarChar(sql.MAX), JSON.stringify(mergedDocs))
                .query(`UPDATE SupplierProfile SET Documents = @documents WHERE SupplierID = @supplierId`);

            // Notify all admins that documents were uploaded and need verification
            const adminIds = await getAdminUserIds(pool);
            for (const adminUserId of adminIds) {
                await createNotification(pool, {
                    userId:  adminUserId,
                    userType: 'admin',
                    message: `${companyName} uploaded ${uploadedDocs.length} document(s) pending verification.`,
                    type:    'info',
                    link:    `/admin/suppliers/${supplierId}/documents`,
                });
            }

            res.status(201).json({ message: 'Documents uploaded successfully', documents: uploadedDocs, totalDocuments: mergedDocs.length });
        } catch (error) {
            console.error('[Upload Documents] Error:', error);
            res.status(500).json({ message: error.message });
        }
    }
);

// Upload experiences
app.post('/api/suppliers/:supplierId/upload-experiences',
    upload.fields(Array.from({ length: 10 }, (_, i) => ({ name: `experienceProof${i}`, maxCount: 1 }))),
    async (req, res) => {
        const { supplierId } = req.params;
        try {
            const pool   = await getPool();
            const result = await pool.request()
                .input('supplierId', sql.VarChar(50), supplierId)
                .query(`SELECT Experiences FROM SupplierProfile WHERE SupplierID = @supplierId`);

            if (result.recordset.length === 0)
                return res.status(404).json({ message: 'Supplier not found' });

            const experienceCount = parseInt(req.body.experienceCount || '0');
            const experiences     = [];

            for (let i = 0; i < experienceCount; i++) {
                const company   = req.body[`experienceCompany${i}`];
                const fileArray = req.files[`experienceProof${i}`];
                const file      = fileArray?.[0];
                if (company) {
                    experiences.push({
                        company,
                        proofFile:  file ? `${supplierId}/${file.filename}` : null,
                        uploadDate: new Date().toISOString().split('T')[0],
                        status:     'Pending'
                    });
                }
            }

            await pool.request()
                .input('supplierId',      sql.VarChar(50),       supplierId)
                .input('experiences',     sql.NVarChar(sql.MAX), JSON.stringify(experiences))
                .input('experienceCount', sql.Int,               experiences.length)
                .input('hasExperiences',  sql.Bit,               experiences.length > 0 ? 1 : 0)
                .query(`
                    UPDATE SupplierProfile SET
                        Experiences     = @experiences,
                        ExperienceCount = @experienceCount,
                        HasExperiences  = @hasExperiences
                    WHERE SupplierID = @supplierId
                `);

            res.json({ message: 'Experiences uploaded successfully', count: experiences.length });
        } catch (error) {
            console.error('[Upload Experiences] Error:', error);
            res.status(500).json({ message: error.message });
        }
    }
);

// ============================================================
// EXPERIENCE VERIFICATION 
// ============================================================

// PATCH /api/suppliers/:supplierId/experiences/:index/verify  — admin only
app.patch('/api/suppliers/:supplierId/experiences/:index/verify', requireAdmin, async (req, res) => {
    const { supplierId, index }        = req.params;
    const { status, rejectionReason }  = req.body;
    const expIndex                     = parseInt(index, 10);

    if (!['Verified', 'Rejected'].includes(status))
        return res.status(400).json({ message: 'Invalid status. Must be Verified or Rejected.' });

    if (isNaN(expIndex) || expIndex < 0)
        return res.status(400).json({ message: 'Invalid experience index.' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT Experiences, CompanyName FROM SupplierProfile WHERE SupplierID = @supplierId`);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Supplier not found' });

        let experiences = result.recordset[0].Experiences
            ? JSON.parse(result.recordset[0].Experiences)
            : [];

        const companyName = result.recordset[0].CompanyName;

        if (expIndex >= experiences.length)
            return res.status(404).json({ message: 'Experience not found at that index' });

        // Update the experience at the given index
        experiences[expIndex] = {
            ...experiences[expIndex],
            status,
            rejectionReason: status === 'Rejected' ? (rejectionReason || null) : undefined,
            verifiedAt: new Date().toISOString(),
        };

        await pool.request()
            .input('supplierId',  sql.VarChar(50),       supplierId)
            .input('experiences', sql.NVarChar(sql.MAX), JSON.stringify(experiences))
            .query(`UPDATE SupplierProfile SET Experiences = @experiences WHERE SupplierID = @supplierId`);

        // Notify the supplier
        const supplierUserId = await getSupplierUserId(pool, supplierId);
        if (supplierUserId) {
            const expCompany = experiences[expIndex].company || 'your experience';
            if (status === 'Verified') {
                await createNotification(pool, {
                    userId:   supplierUserId,
                    userType: 'supplier',
                    message:  `Your experience proof for "${expCompany}" has been verified and approved.`,
                    type:     'success',
                    link:     '/supplier/profile',
                });
            } else {
                await createNotification(pool, {
                    userId:   supplierUserId,
                    userType: 'supplier',
                    message:  `Your experience proof for "${expCompany}" was rejected.${rejectionReason ? ' Reason: ' + rejectionReason : ' Please re-upload.'}`,
                    type:     'error',
                    link:     '/supplier/profile',
                });
            }
        }

        res.json({ message: `Experience ${status.toLowerCase()} successfully` });
    } catch (error) {
        console.error('[PATCH experience verify] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// Renew a document
app.post('/api/suppliers/:supplierId/documents/:docType/renew', requireAuth, upload.single('document'), async (req, res) => {
    const { supplierId, docType } = req.params;
    const { expiryDate }          = req.body;
    const file = req.file;

    if (!file) return res.status(400).json({ message: 'No file uploaded' });
    const config = DOCUMENT_CONFIG[docType];
    if (!config) return res.status(400).json({ message: 'Invalid document type' });

    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT Documents, CompanyName FROM SupplierProfile WHERE SupplierID = @supplierId`);

        if (result.recordset.length === 0)
            return res.status(404).json({ message: 'Supplier not found' });

        let documents = result.recordset[0].Documents ? JSON.parse(result.recordset[0].Documents) : [];
        const companyName = result.recordset[0].CompanyName;

        documents = documents.map(doc =>
            (doc.docType === docType && doc.status !== 'Replaced')
                ? { ...doc, status: 'Replaced', replacedAt: new Date().toISOString(), replacedBy: file.filename }
                : doc
        );

        const newDocument = {
            name:           config.name,
            fileName:       `${supplierId}/${file.filename}`,
            docType,
            status:         'Pending',
            uploadDate:     new Date().toISOString().split('T')[0],
            expiryDate:     expiryDate || null,
            requiresExpiry: config.requiresExpiry,
            isRenewal:      true
        };
        documents.push(newDocument);

        await pool.request()
            .input('supplierId', sql.VarChar(50),       supplierId)
            .input('documents',  sql.NVarChar(sql.MAX), JSON.stringify(documents))
            .query(`UPDATE SupplierProfile SET Documents = @documents WHERE SupplierID = @supplierId`);

        // Notify all admins that a document was renewed and needs verification
        const adminIds = await getAdminUserIds(pool);
        for (const adminUserId of adminIds) {
            await createNotification(pool, {
                userId:  adminUserId,
                userType: 'admin',
                message: `${companyName} renewed their "${config.name}" document and it requires verification.`,
                type:    'info',
                link:    `/admin/suppliers/${supplierId}/documents`,
            });
        }

        res.json({ message: 'Document renewed successfully', document: newDocument });
    } catch (error) {
        console.error('[Renew Document] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// Admin: verify a document
app.patch('/api/suppliers/:supplierId/documents/:docType/verify', requireAdmin, async (req, res) => {
    const { supplierId, docType }     = req.params;
    const { status, rejectionReason } = req.body;

    try {
        const pool = await getPool();
        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            // Using UPDLOCK + HOLDLOCK to serialize concurrent writes to this row
            const result = await transaction.request()
                .input('supplierId', sql.VarChar(50), supplierId)
                .query(`
                    SELECT Documents 
                    FROM SupplierProfile WITH (UPDLOCK, HOLDLOCK)
                    WHERE SupplierID = @supplierId
                `);

            if (result.recordset.length === 0) {
                await transaction.rollback();
                return res.status(404).json({ message: 'Supplier not found' });
            }

            let documents = result.recordset[0].Documents
                ? JSON.parse(result.recordset[0].Documents)
                : [];

            documents = documents.map(doc =>
                (doc.docType === docType && doc.status === 'Pending')
                    ? { ...doc, status, rejectionReason: status === 'Rejected' ? rejectionReason : undefined, verifiedAt: new Date().toISOString() }
                    : doc
            );

            await transaction.request()
                .input('supplierId', sql.VarChar(50),       supplierId)
                .input('documents',  sql.NVarChar(sql.MAX), JSON.stringify(documents))
                .query(`UPDATE SupplierProfile SET Documents = @documents WHERE SupplierID = @supplierId`);

            await transaction.commit();
        } catch (err) {
            await transaction.rollback();
            throw err;
        }

        // notifications outside transaction (non-critical)
        const supplierUserId = await getSupplierUserId(pool, supplierId);
        if (supplierUserId) {
            const docName = DOCUMENT_CONFIG[docType]?.name || docType;
            await createNotification(pool, {
                userId: supplierUserId, userType: 'supplier',
                message: status === 'Verified'
                    ? `Your document "${docName}" has been verified and approved.`
                    : `Your document "${docName}" was rejected.${rejectionReason ? ' Reason: ' + rejectionReason : ' Please re-upload.'}`,
                type: status === 'Verified' ? 'success' : 'error',
                link: '/supplier/documents',
            });
        }

        res.json({ message: `Document ${status.toLowerCase()} successfully` });
    } catch (error) {
        console.error('[Verify Document] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// ============================================================
// GET SINGLE BID WITH ITEMS BY BID ID
// ============================================================

// GET /api/bids/:bidId - Get single bid with its items
app.get('/api/bids/:bidId', requireAuth, async (req, res) => {
    const { bidId } = req.params;
    const { userId, role } = req.user;
    
    try {
        const pool = await getPool();
        
        // Get supplier ID for access control (if supplier)
        let userSupplierId = null;
        if (role === 'supplier') {
            // For suppliers, userId in JWT is the SupplierID
            userSupplierId = userId;
        }
        
        // Fetch the bid with tender details
        let query = `
            SELECT
                b.BidID AS bidId,
                b.TenderID AS tenderId,
                t.Title AS tenderTitle,
                b.SupplierID AS supplierId,
                sp.CompanyName AS supplierName,
                b.SubmittedDate AS submittedDate,
                b.GrandTotal AS grandTotal,
                bs.BidStatusName AS status,
                b.ComplianceScore,
                b.EvaluationScore,
                b.CreatedAt
            FROM Bid b
            JOIN Tender t ON b.TenderID = t.TenderID
            JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
            JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
            WHERE b.BidID = @bidId
        `;
        
        // Add access restriction for suppliers
        if (role === 'supplier') {
            query += ` AND b.SupplierID = @supplierId`;
        }
        
        const result = await pool.request()
            .input('bidId', sql.VarChar(50), bidId)
            .input('supplierId', sql.VarChar(50), userSupplierId)
            .query(query);
        
        if (result.recordset.length === 0) {
            return res.status(404).json({ message: 'Bid not found or access denied' });
        }
        
        const bid = result.recordset[0];
        
        // Fetch bid items
        const itemsResult = await pool.request()
            .input('bidId', sql.VarChar(50), bidId)
            .query(`
                SELECT 
                    ItemNo AS itemNo,
                    TenderItemID AS tenderItemId,
                    Description AS description,
                    Unit AS unit,
                    Quantity AS quantity,
                    UnitPrice AS unitPrice,
                    Total AS total
                FROM BidItem 
                WHERE BidID = @bidId 
                ORDER BY ItemNo ASC
            `);
        
        bid.items = itemsResult.recordset;
        
        console.log(`[GET /api/bids/${bidId}] Found bid: ${bid.bidId} with ${bid.items.length} items for supplier: ${bid.supplierId}`);
        
        res.json(bid);
        
    } catch (error) {
        console.error('[GET /api/bids/:bidId] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// ============================================================
// SUPPLIER — EXPERIENCES & INTERESTS
// ============================================================

app.get('/api/suppliers/:supplierId/experiences', requireAuth, async (req, res) => {
    const { supplierId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT Experiences, ExperienceCount, HasExperiences FROM SupplierProfile WHERE SupplierID = @supplierId`);

        if (result.recordset.length === 0) return res.status(404).json({ message: 'Supplier not found' });

        const s = result.recordset[0];
        res.json({
            experiences:     s.Experiences ? JSON.parse(s.Experiences) : [],
            experienceCount: s.ExperienceCount || 0,
            hasExperiences:  s.HasExperiences  || false
        });
    } catch (error) {
        console.error('[GET experiences] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/suppliers/:supplierId/experience-documents', requireAuth, async (req, res) => {
    const { supplierId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT Experiences FROM SupplierProfile WHERE SupplierID = @supplierId`);

        if (result.recordset.length === 0) return res.status(404).json({ message: 'Supplier not found' });

        const experiences = result.recordset[0].Experiences ? JSON.parse(result.recordset[0].Experiences) : [];
        res.json(
            experiences
                .filter(exp => exp.proofFile)
                .map(exp => ({ company: exp.company, fileName: exp.proofFile, uploadDate: exp.uploadDate || null, status: exp.status || 'Pending' }))
        );
    } catch (error) {
        console.error('[GET experience-documents] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/suppliers/:supplierId/interests', requireAuth, async (req, res) => {
    const { supplierId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`
                SELECT i.TenderID AS tenderId, t.Title AS tenderTitle, i.InterestDate AS date
                FROM Interests i JOIN Tender t ON i.TenderID = t.TenderID
                WHERE i.SupplierID = @supplierId ORDER BY i.InterestDate DESC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET supplier interests] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// BIDS
// ============================================================

// GET /api/bids  — admin
app.get('/api/bids', requireAdmin, async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT
                b.BidID AS bidId, b.TenderID AS tenderId, t.Title AS tenderTitle,
                b.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                b.SubmittedDate AS submittedDate, b.GrandTotal AS grandTotal,
                bs.BidStatusName AS status, b.CreatedAt
            FROM Bid b
            JOIN Tender          t  ON b.TenderID   = t.TenderID
            JOIN SupplierProfile sp ON b.SupplierID  = sp.SupplierID
            JOIN BidStatus       bs ON b.BidStatusID = bs.BidStatusID
            ORDER BY b.CreatedAt DESC
        `);

        const bids           = result.recordset;
        const allItemsResult = await pool.request().query(`
            SELECT BidID AS bidId, ItemNo AS itemNo, TenderItemID AS tenderItemId, Description, Unit, Quantity, UnitPrice, Total
            FROM BidItem ORDER BY BidID, ItemNo , TenderItemID ASC
        `);

        const itemMap = {};
        allItemsResult.recordset.forEach(row => {
            if (!itemMap[row.BidID]) itemMap[row.BidID] = [];
            itemMap[row.BidID].push(row);
        });
        bids.forEach(bid => { bid.items = itemMap[bid.bidId] || []; });

        res.json(bids);
    } catch (error) {
        console.error('[GET /api/bids] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// GET /api/bids/tender/:tenderId  — admin
app.get('/api/bids/tender/:tenderId', requireAdmin, async (req, res) => {
    const { tenderId } = req.params;
    try {
        const pool       = await getPool();
        const bidsResult = await pool.request()
            .input('tenderId', sql.VarChar(50), tenderId)
            .query(`
                SELECT
                    b.BidID AS bidId, b.TenderID AS tenderId,
                    b.SupplierID AS supplierId, sp.CompanyName AS supplierName,
                    b.SubmittedDate AS submittedDate, b.GrandTotal AS grandTotal,
                    bs.BidStatusName AS status, b.ComplianceScore, b.EvaluationScore, b.CreatedAt
                FROM Bid b
                JOIN SupplierProfile sp ON b.SupplierID  = sp.SupplierID
                JOIN BidStatus       bs ON b.BidStatusID = bs.BidStatusID
                WHERE b.TenderID = @tenderId ORDER BY b.SubmittedDate DESC
            `);

        const bids = bidsResult.recordset;
        if (bids.length > 0) {
            const bidIds         = bids.map(b => `'${b.bidId}'`).join(',');
            const allItemsResult = await pool.request().query(`
                SELECT BidID AS bidId, ItemNo AS itemNo, TenderItemID AS tenderItemId, Description, Unit, Quantity, UnitPrice, Total
                FROM BidItem WHERE BidID IN (${bidIds}) ORDER BY BidID, ItemNo , TenderItemID ASC
            `);
            const itemMap = {};
            allItemsResult.recordset.forEach(row => {
                if (!itemMap[row.BidID]) itemMap[row.BidID] = [];
                itemMap[row.BidID].push(row);
            });
            bids.forEach(bid => { bid.items = itemMap[bid.bidId] || []; });
        }

        res.json(bids);
    } catch (error) {
        console.error('[GET /api/bids/tender/:tenderId] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// GET /api/bids/supplier/:supplierId
app.get('/api/bids/supplier/:supplierId', requireAuth, async (req, res) => {
    const { supplierId } = req.params;
    try {
        const pool = await getPool();
        const bidsResult = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`
                SELECT
                    b.BidID          AS bidId,      
                    b.TenderID       AS tenderId,
                    t.Title          AS tenderTitle,  
                    b.SupplierID     AS supplierId,  
                    sp.CompanyName   AS supplierName,
                    b.SubmittedDate  AS submittedDate, 
                    b.GrandTotal     AS grandTotal,
                    bs.BidStatusName AS status,
                    b.ComplianceScore, 
                    b.EvaluationScore, 
                    b.CreatedAt
                FROM Bid b
                JOIN Tender t ON b.TenderID = t.TenderID 
                JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
                JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
                WHERE b.SupplierID = @supplierId
                ORDER BY b.SubmittedDate DESC
            `);

        const bids = bidsResult.recordset;
        
        if (bids.length > 0) {
            const bidIds = bids.map(b => `'${b.bidId}'`).join(',');
            const allItemsResult = await pool.request().query(`
                SELECT 
                    BidID AS bidId, 
                    ItemNo AS itemNo, 
                    TenderItemID AS tenderItemId, 
                    Description, 
                    Unit, 
                    Quantity, 
                    UnitPrice, 
                    Total
                FROM BidItem 
                WHERE BidID IN (${bidIds}) 
                ORDER BY BidID, ItemNo ASC
            `);
            
            const itemMap = {};
            allItemsResult.recordset.forEach(row => {
                if (!itemMap[row.bidId]) itemMap[row.bidId] = [];
                itemMap[row.bidId].push({
                    itemNo: row.itemNo,
                    tenderItemId: row.tenderItemId,
                    description: row.Description,
                    unit: row.Unit,
                    quantity: row.Quantity,
                    unitPrice: row.UnitPrice,
                    total: row.Total
                });
            });
            bids.forEach(bid => { 
                bid.items = itemMap[bid.bidId] || []; 
            });
        }

        res.json(bids);
    } catch (error) {
        console.error('[GET /api/bids/supplier/:supplierId] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// POST /api/bids  — auth required
app.post('/api/bids', requireAuth, async (req, res) => {
    const { bidId, tenderId, supplierId, grandTotal, submittedDate, items } = req.body;

    if (!bidId || !tenderId || !supplierId)
        return res.status(400).json({ message: 'bidId, tenderId, and supplierId are required' });

    try {
        const pool = await getPool();

        // 1. Check supplier has expressed interest before bidding
        const interestCheck = await pool.request()
            .input('tenderId',   sql.VarChar(50), tenderId)
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT 1 FROM Interests WHERE TenderID = @tenderId AND SupplierID = @supplierId`);

        if (interestCheck.recordset.length === 0)
            return res.status(403).json({ message: 'You must express interest in this tender before submitting a bid' });

        // 2. Check for duplicate bid
        const existingBid = await pool.request()
            .input('tenderId',   sql.VarChar(50), tenderId)
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT BidID FROM Bid WHERE TenderID = @tenderId AND SupplierID = @supplierId`);

        if (existingBid.recordset.length > 0)
            return res.status(400).json({ message: 'You have already submitted a bid for this tender' });

        // Fetch tender title and supplier name before transaction for notifications
        const tenderInfo = await pool.request()
            .input('tenderId', sql.VarChar(50), tenderId)
            .query(`SELECT Title FROM Tender WHERE TenderID = @tenderId`);

        const supplierInfo = await pool.request()
            .input('supplierId', sql.VarChar(50), supplierId)
            .query(`SELECT CompanyName FROM SupplierProfile WHERE SupplierID = @supplierId`);

        const tenderTitle = tenderInfo.recordset[0]?.Title        || 'a tender';
        const companyName = supplierInfo.recordset[0]?.CompanyName || 'A supplier';

        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('bidId',         sql.VarChar(50),   bidId)
                .input('tenderId',      sql.VarChar(50),   tenderId)
                .input('supplierId',    sql.VarChar(50),   supplierId)
                .input('submittedDate', sql.Date,          submittedDate || new Date().toISOString().split('T')[0])
                .input('grandTotal',    sql.Decimal(18,2), grandTotal || 0)
                .input('bidStatusId',   sql.VarChar(20),   'BS001')
                .query(`
                    INSERT INTO Bid (BidID, TenderID, SupplierID, SubmittedDate, GrandTotal, BidStatusID, CreatedAt)
                    VALUES (@bidId, @tenderId, @supplierId, @submittedDate, @grandTotal, @bidStatusId, GETDATE())
                `);

            if (items && items.length > 0) {
                for (const item of items) {
                    await transaction.request()
                        .input('bidId',        sql.VarChar(50),       bidId)
                        .input('itemNo',       sql.Int,               item.itemNo)
                        .input('description',  sql.NVarChar(sql.MAX), item.description || '')
                        .input('unit',         sql.NVarChar(50),      item.unit || '')
                        .input('quantity',     sql.Decimal(18,2),     item.quantity || 0)
                        .input('unitPrice',    sql.Decimal(18,2),     item.unitPrice  || 0)
                        .input('total',        sql.Decimal(18,2),     item.total      || 0)
                        .input('tenderItemId', sql.VarChar(50),       item.tenderItemId || '')
                        .query(`
                            INSERT INTO BidItem
                                (BidID, ItemNo, Description, Unit, Quantity, UnitPrice, Total, CreatedAt, TenderItemID)
                            VALUES
                                (@bidId, @itemNo, @description, @unit, @quantity, @unitPrice, @total, GETDATE(), @tenderItemId)
                        `);
                }
            }

            await transaction.commit();

            // Notify all admins about the new bid
            const adminIds = await getAdminUserIds(pool);
            for (const adminUserId of adminIds) {
                await createNotification(pool, {
                    userId:   adminUserId,
                    userType: 'admin',
                    message:  `${companyName} submitted a bid for "${tenderTitle}".`,
                    type:     'info',
                    link:     `/admin/tenders/${tenderId}`,
                });
            }

            res.status(201).json({ message: 'Bid submitted successfully', bid: { bidId, tenderId, supplierId, grandTotal } });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[POST /api/bids] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// PATCH /api/bids/:id/status  — admin only
app.patch('/api/bids/:id/status', requireAdmin, async (req, res) => {
    const { id }           = req.params;
    const { status, note } = req.body;

    const bidStatusMap = { Awarded: 'BS002', Rejected: 'BS003' };
    const bidStatusId  = bidStatusMap[status];
    if (!bidStatusId) return res.status(400).json({ message: 'Invalid status' });

    try {
        const pool      = await getPool();
        const bidResult = await pool.request()
            .input('bidId', sql.VarChar(50), id)
            .query(`
                SELECT b.*, t.Title AS tenderTitle, sp.CompanyName AS supplierName
                FROM Bid b
                JOIN Tender          t  ON b.TenderID   = t.TenderID
                JOIN SupplierProfile sp ON b.SupplierID  = sp.SupplierID
                WHERE b.BidID = @bidId
            `);

        if (bidResult.recordset.length === 0)
            return res.status(404).json({ message: 'Bid not found' });

        const bid         = bidResult.recordset[0];
        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('bidId',       sql.VarChar(50), id)
                .input('bidStatusId', sql.VarChar(20), bidStatusId)
                .query(`UPDATE Bid SET BidStatusID = @bidStatusId WHERE BidID = @bidId`);

            if (status === 'Awarded') {
                await transaction.request()
                    .input('tenderId',    sql.VarChar(50),       bid.TenderID)
                    .input('supplierId',  sql.VarChar(50),       bid.SupplierID)
                    .input('awardAmount', sql.Decimal(18,2),     bid.GrandTotal)
                    .input('awardNote',   sql.NVarChar(sql.MAX), note || null)
                    .query(`
                        UPDATE Tender SET
                            TenderStatusID = 'TS004',
                            AwardedTo      = @supplierId,
                            AwardAmount    = @awardAmount,
                            AwardDate      = GETDATE(),
                            AwardNote      = @awardNote,
                            UpdatedAt      = GETDATE()
                        WHERE TenderID = @tenderId
                    `);
            }

            await transaction.commit();

            // Notify the supplier about their bid outcome
            const supplierUserId = await getSupplierUserId(pool, bid.SupplierID);
            if (supplierUserId) {
                if (status === 'Awarded') {
                    await createNotification(pool, {
                        userId:  supplierUserId,
                        message: `Congratulations! Your bid for "${bid.tenderTitle}" has been awarded.`,
                        type:    'success',
                        link:    '/supplier/bids',
                    });
                } else if (status === 'Rejected') {
                    await createNotification(pool, {
                        userId:  supplierUserId,
                        message: `Your bid for "${bid.tenderTitle}" was not successful.`,
                        type:    'error',
                        link:    '/supplier/bids',
                    });
                }
            }

            res.json({ message: `Bid ${status.toLowerCase()} successfully`, bid: { id, status } });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[PATCH /api/bids/:id/status] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// ============================================================
// NOTIFICATIONS
// ============================================================



app.get('/api/notifications/:userId', requireAuth, async (req, res) => {
    const { userId } = req.params;
    try {
        const pool   = await getPool();
        const result = await pool.request()
            .input('userId', sql.VarChar(50), userId)
            .query(`
                SELECT
                    n.NotificationID AS id, n.Message AS message,
                    nt.NotificationTypeName AS type,
                    n.Timestamp AS timestamp, n.IsRead AS [read], n.Link AS link
                FROM Notifications n
                JOIN NotificationType nt ON n.NotificationTypeID = nt.NotificationTypeID
                WHERE n.UserID = @userId ORDER BY n.Timestamp DESC
            `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET notifications] Error:', error);
        res.json([]);
    }
});


app.patch('/api/notifications/:id/read', requireAuth, async (req, res) => {
    const { id } = req.params;
    try {
        const pool = await getPool();
        await pool.request()
            .input('notificationId', sql.VarChar(50), id)
            .query(`UPDATE Notifications SET IsRead = 1 WHERE NotificationID = @notificationId`);
        res.json({ message: 'Notification marked as read' });
    } catch (error) {
        console.error('[PATCH notification read] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// ADMIN — USER MANAGEMENT
// ============================================================

app.get('/api/admin/users', requireAdmin, async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT ap.AdminID AS id, ap.Name AS name, su.Email AS email, ap.Role AS role,
                   su.LastLogin AS lastLogin, us.UserStatusName AS status
            FROM AdminProfiles ap
            JOIN SystemUser su ON ap.AdminID      = su.AdminID
            JOIN UserStatus us ON ap.UserStatusID = us.UserStatusID
            WHERE su.Role = 'admin' ORDER BY ap.CreateDate DESC
        `);
        res.json(result.recordset);
    } catch (error) {
        console.error('[GET /api/admin/users] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.post('/api/admin/users', requireAdmin, async (req, res) => {
    const { name, email, role, password } = req.body;
    if (!name || !email || !role || !password)
        return res.status(400).json({ message: 'All fields are required' });

    try {
        const pool     = await getPool();
        const existing = await pool.request()
            .input('email', sql.VarChar(255), email)
            .query(`SELECT Email FROM SystemUser WHERE Email = @email`);

        if (existing.recordset.length > 0)
            return res.status(400).json({ message: 'User already exists' });

        const adminId        = generateId('ADM');
        const userId         = generateId('USR');
        const hashedPassword = await bcrypt.hash(password, 10);

        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('adminId',      sql.VarChar(50),  adminId)
                .input('name',         sql.NVarChar(255), name)
                .input('email',        sql.VarChar(255), email)
                .input('role',         sql.NVarChar(50), role)
                .input('userStatusId', sql.VarChar(20),  'UST001')
                .query(`INSERT INTO AdminProfiles (AdminID, Name, Email, Role, UserStatusID, CreateDate) VALUES (@adminId, @name, @email, @role, @userStatusId, GETDATE())`);

            // IsFirstLogin = 1 so newly created admins are prompted to
            //      change their password on first login
            await transaction.request()
                .input('userId',       sql.VarChar(50),  userId)
                .input('email',        sql.VarChar(255), email)
                .input('passwordHash', sql.VarChar(255), hashedPassword)
                .input('role',         sql.VarChar(20),  'admin')
                .input('adminId',      sql.VarChar(50),  adminId)
                .input('userStatusId', sql.VarChar(20),  'UST001')
                .query(`
                    INSERT INTO SystemUser
                        (UserID, Email, PasswordHash, Role, AdminID, UserStatusID, IsFirstLogin, CreateDate)
                    VALUES
                        (@userId, @email, @passwordHash, @role, @adminId, @userStatusId, 1, GETDATE())
                `);

            await transaction.commit();
            res.status(201).json({ id: adminId, name, email, role, lastLogin: null, status: 'Active' });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[POST /api/admin/users] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// DELETE — removes both SystemUser (FK child) and AdminProfiles (FK parent)
app.delete('/api/admin/users/:id', requireAdmin, async (req, res) => {
    const { id } = req.params;
    try {
        const pool  = await getPool();
        const check = await pool.request()
            .input('adminId', sql.VarChar(50), id)
            .query(`SELECT AdminID FROM AdminProfiles WHERE AdminID = @adminId`);

        if (check.recordset.length === 0)
            return res.status(404).json({ message: 'User not found' });

        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            await transaction.request()
                .input('adminId', sql.VarChar(50), id)
                .query(`DELETE FROM SystemUser WHERE AdminID = @adminId`);

            await transaction.request()
                .input('adminId', sql.VarChar(50), id)
                .query(`DELETE FROM AdminProfiles WHERE AdminID = @adminId`);

            await transaction.commit();
            res.json({ message: 'User deleted successfully' });
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    } catch (error) {
        console.error('[DELETE /api/admin/users/:id] Error:', error);
        res.status(500).json({ message: error.message });
    }
});


// ============================================================
// ADMIN — TENDER MAINTENANCE
// ============================================================

app.get('/api/admin/update-tender-statuses', requireAdmin, async (req, res) => {
    try {
        const pool  = await getPool();
        const today = new Date().toISOString().split('T')[0];

        const openResult  = await pool.request()
            .input('today', sql.Date, today)
            .query(`UPDATE Tender SET TenderStatusID = 'TS002', UpdatedAt = GETDATE() WHERE TenderStatusID = 'TS001' AND OpeningDate <= @today AND ClosingDate > @today`);

        const closeResult = await pool.request()
            .input('today', sql.Date, today)
            .query(`UPDATE Tender SET TenderStatusID = 'TS003', UpdatedAt = GETDATE() WHERE TenderStatusID = 'TS002' AND ClosingDate < @today`);

        res.json({
            message:   'Tender statuses updated',
            opened:    openResult.rowsAffected[0],
            closed:    closeResult.rowsAffected[0],
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('[update-tender-statuses] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/admin/check-closing-tenders', requireAdmin, async (req, res) => {
    try {
        const pool  = await getPool();
        const today = new Date();
        const in3   = new Date(); in3.setDate(today.getDate() + 3);

        const result = await pool.request()
            .input('today',     sql.Date, today.toISOString().split('T')[0])
            .input('threeDays', sql.Date, in3.toISOString().split('T')[0])
            .query(`
                SELECT t.TenderID AS tenderid, t.Title, t.ClosingDate AS closingdate,
                       t.CategoryID, tc.TenderCategoryName AS categoryname
                FROM Tender t JOIN TenderCategory tc ON t.CategoryID = tc.TenderCategoryID
                WHERE t.TenderStatusID = 'TS002' AND t.ClosingDate BETWEEN @today AND @threeDays
            `);

        res.json({ message: `Found ${result.recordset.length} tenders closing soon`, count: result.recordset.length, newNotifications: 0, tenders: result.recordset });
    } catch (error) {
        console.error('[check-closing-tenders] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

app.get('/api/admin/check-expiring-documents', requireAdmin, async (req, res) => {
    try {
        const pool   = await getPool();
        const result = await pool.request().query(`
            SELECT SupplierID, CompanyName, Email, Documents
            FROM SupplierProfile WHERE Documents IS NOT NULL AND Documents != '[]'
        `);

        const today             = new Date();
        const expiringDocuments = [];

        for (const supplier of result.recordset) {
            const documents = JSON.parse(supplier.Documents || '[]');
            for (const doc of documents) {
                if (doc.expiryDate && doc.requiresExpiry && doc.status !== 'Replaced') {
                    const daysUntilExpiry = Math.ceil((new Date(doc.expiryDate) - today) / 86400000);
                    if (daysUntilExpiry <= 30) {
                        expiringDocuments.push({
                            supplierId:   supplier.SupplierID,
                            supplierName: supplier.CompanyName,
                            documentName: doc.name,
                            expiryDate:   doc.expiryDate,
                            daysUntilExpiry
                        });
                    }
                }
            }
        }

        res.json({ message: 'Document expiry check completed', expiringCount: expiringDocuments.length, notificationsSent: expiringDocuments.length, expiringDocuments });
    } catch (error) {
        console.error('[check-expiring-documents] Error:', error);
        res.status(500).json({ message: error.message });
    }
});

// ============================================================
// BID DOWNLOAD ENDPOINTS
// ============================================================

const PDFDocument = require('pdfkit');
const { Parser } = require('json2csv');

// Helper: Get supplier ID from authenticated user
async function getSupplierIdFromAuth(pool, userId, role) {
  if (role === 'supplier') {
    const result = await pool.request()
      .input('userId', sql.VarChar(50), userId)
      .query(`SELECT SupplierID FROM SystemUser WHERE UserID = @userId AND Role = 'supplier'`);
    return result.recordset[0]?.SupplierID;
  }
  return null;
}

// GET /api/bids/supplier/:supplierId/export - Export all bids as CSV
app.get('/api/bids/supplier/:supplierId/export', requireAuth, async (req, res) => {
  const { supplierId } = req.params;
  const { userId, role } = req.user; 

  try {
    const pool = await getPool();
    
    // Verify supplier has access
    if (role === 'supplier') {
      // For suppliers, userId in JWT IS the SupplierID
      if (userId !== supplierId) {
        return res.status(403).json({ message: 'You can only export your own bids' });
      }
    }

    // Fetch all bids for this supplier
    const bidsResult = await pool.request()
      .input('supplierId', sql.VarChar(50), supplierId)
      .query(`
        SELECT 
          b.BidID,
          b.SubmittedDate,
          b.GrandTotal,
          bs.BidStatusName AS Status,
          t.TenderID,
          t.Title AS TenderTitle,
          t.ClosingDate,
          tc.TenderCategoryName AS Category,
          sp.CompanyName
        FROM Bid b
        JOIN Tender t ON b.TenderID = t.TenderID
        JOIN TenderCategory tc ON t.CategoryID = tc.TenderCategoryID
        JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
        JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
        WHERE b.SupplierID = @supplierId
        ORDER BY b.SubmittedDate DESC
      `);

    const bids = bidsResult.recordset;
    
    // Fetch items for each bid
    for (const bid of bids) {
      const itemsResult = await pool.request()
        .input('bidId', sql.VarChar(50), bid.BidID)
        .query(`
          SELECT 
            ItemNo,
            TenderItemID,
            Description,
            Unit,
            Quantity,
            UnitPrice,
            Total
          FROM BidItem
          WHERE BidID = @bidId
          ORDER BY ItemNo ASC
        `);
      bid.Items = itemsResult.recordset;
    }

    // Flatten data for CSV
    const csvData = [];
    for (const bid of bids) {
      if (bid.Items && bid.Items.length > 0) {
        bid.Items.forEach(item => {
          csvData.push({
            'Bid ID': bid.BidID,
            'Submitted Date': new Date(bid.SubmittedDate).toLocaleString(),
            'Status': bid.Status,
            'Tender ID': bid.TenderID,
            'Tender Title': bid.TenderTitle,
            'Category': bid.Category,
            'Closing Date': new Date(bid.ClosingDate).toLocaleDateString(),
            'Item No': item.ItemNo,
            'Item Code': item.TenderItemID,
            'Description': item.Description,
            'Unit': item.Unit,
            'Quantity': item.Quantity,
            'Unit Price': item.UnitPrice,
            'Item Total': item.Total,
            'Bid Grand Total': bid.GrandTotal,
            'Company': bid.CompanyName
          });
        });
      }
    }

    const { Parser } = require('json2csv');
    const fields = [
      'Bid ID', 'Submitted Date', 'Status', 'Tender ID', 'Tender Title', 
      'Category', 'Closing Date', 'Item No', 'Item Code', 'Description', 
      'Unit', 'Quantity', 'Unit Price', 'Item Total', 'Bid Grand Total', 'Company'
    ];
    
    const json2csvParser = new Parser({ fields });
    const csv = json2csvParser.parse(csvData);
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="All_Bids_Export_${new Date().toISOString().split('T')[0]}.csv"`);
    res.send(csv);
    
  } catch (error) {
    console.error('[Export Bids CSV] Error:', error);
    res.status(500).json({ message: error.message });
  }
});


// GET /api/bids/:bidId/download - Download single bid as PDF
app.get('/api/bids/:bidId/download', requireAuth, async (req, res) => {
  const { bidId } = req.params;
  const { userId, role } = req.user;  // userId = SupplierID for suppliers

  try {
    const pool = await getPool();
    
    let userSupplierId = null;
    if (role === 'supplier') {
      // For suppliers, userId in JWT IS the SupplierID directly
      userSupplierId = userId;
      
      // Optional: Verify the supplier exists
      const supplierCheck = await pool.request()
        .input('supplierId', sql.VarChar(50), userSupplierId)
        .query(`SELECT SupplierID FROM SupplierProfile WHERE SupplierID = @supplierId`);
      
      if (supplierCheck.recordset.length === 0) {
        return res.status(403).json({ message: 'Supplier profile not found' });
      }
    }

    // Fetch bid data with access control
    let query = `
      SELECT 
        b.BidID, 
        b.SubmittedDate, 
        b.GrandTotal, 
        bs.BidStatusName AS Status,
        t.TenderID, 
        t.Title, 
        t.Description AS TenderDescription,
        t.ClosingDate, 
        t.EstimatedBudget,
        t.CategoryID,
        tc.TenderCategoryName AS CategoryName,
        sp.CompanyName, 
        sp.RegistrationNumber, 
        sp.ContactPerson, 
        sp.Email,
        sp.Phone,
        sp.Address
      FROM Bid b
      JOIN Tender t ON b.TenderID = t.TenderID
      JOIN TenderCategory tc ON t.CategoryID = tc.TenderCategoryID
      JOIN SupplierProfile sp ON b.SupplierID = sp.SupplierID
      JOIN BidStatus bs ON b.BidStatusID = bs.BidStatusID
      WHERE b.BidID = @bidId
    `;
    
    // Add access restriction for suppliers
    if (role === 'supplier') {
      query += ` AND b.SupplierID = @supplierId`;
    }
    
    const result = await pool.request()
      .input('bidId', sql.VarChar(50), bidId)
      .input('supplierId', sql.VarChar(50), userSupplierId)
      .query(query);

    if (result.recordset.length === 0) {
      return res.status(404).json({ message: 'Bid not found or access denied' });
    }

    const bid = result.recordset[0];

    // Fetch bid items
    const itemsResult = await pool.request()
      .input('bidId', sql.VarChar(50), bidId)
      .query(`
        SELECT 
          ItemNo, 
          TenderItemID, 
          Description, 
          Unit, 
          Quantity, 
          UnitPrice, 
          Total
        FROM BidItem 
        WHERE BidID = @bidId 
        ORDER BY ItemNo ASC
      `);

    const items = itemsResult.recordset;

    // Generate PDF
    const PDFDocument = require('pdfkit');
    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="Bid_${bidId}_Receipt.pdf"`);
    
    doc.pipe(res);

    // PDF Header
    doc.fontSize(20).font('Helvetica-Bold').text('BID CONFIRMATION RECEIPT', { align: 'center' });
    doc.moveDown();
    doc.fontSize(10).font('Helvetica').text(`Generated: ${new Date().toLocaleString()}`, { align: 'center' });
    doc.moveDown(2);

    // Bid Reference Box
    doc.rect(50, doc.y, 495, 60).stroke();
    doc.fontSize(10).font('Helvetica-Bold').text('BID REFERENCE:', 60, doc.y + 10);
    doc.font('Helvetica').text(bid.BidID, 60, doc.y + 25);
    doc.font('Helvetica-Bold').text('SUBMITTED DATE:', 300, doc.y + 10);
    doc.font('Helvetica').text(new Date(bid.SubmittedDate).toLocaleString(), 300, doc.y + 25);
    doc.font('Helvetica-Bold').text('STATUS:', 60, doc.y + 40);
    const statusColor = bid.Status === 'Awarded' ? 'green' : (bid.Status === 'Rejected' ? 'red' : 'orange');
    doc.fillColor(statusColor).text(bid.Status, 120, doc.y + 40).fillColor('black');
    doc.moveDown(3);

    // Tender Details
    doc.fontSize(14).font('Helvetica-Bold').text('TENDER DETAILS', { underline: true });
    doc.moveDown(0.5);
    doc.fontSize(10).font('Helvetica');
    
    const tenderStartY = doc.y;
    doc.text(`Tender ID:`, 50, tenderStartY);
    doc.text(bid.TenderID, 150, tenderStartY);
    doc.text(`Category:`, 300, tenderStartY);
    doc.text(bid.CategoryName, 380, tenderStartY);
    doc.text(`Title:`, 50, tenderStartY + 20);
    doc.text(bid.Title, 150, tenderStartY + 20);
    doc.text(`Closing Date:`, 50, tenderStartY + 40);
    doc.text(new Date(bid.ClosingDate).toLocaleDateString(), 150, tenderStartY + 40);
    doc.text(`Estimated Budget:`, 300, tenderStartY + 40);
    doc.text(`GHS ${parseFloat(bid.EstimatedBudget).toFixed(2)}`, 430, tenderStartY + 40);
    doc.moveDown(4);

    // Supplier Details
    doc.fontSize(14).font('Helvetica-Bold').text('SUPPLIER DETAILS', { underline: true });
    doc.moveDown(0.5);
    doc.fontSize(10).font('Helvetica');
    
    const supplierStartY = doc.y;
    doc.text(`Company Name:`, 50, supplierStartY);
    doc.text(bid.CompanyName, 160, supplierStartY);
    doc.text(`Reg Number:`, 300, supplierStartY);
    doc.text(bid.RegistrationNumber, 400, supplierStartY);
    doc.text(`Contact Person:`, 50, supplierStartY + 20);
    doc.text(bid.ContactPerson, 160, supplierStartY + 20);
    doc.text(`Email:`, 300, supplierStartY + 20);
    doc.text(bid.Email, 350, supplierStartY + 20);
    doc.text(`Phone:`, 50, supplierStartY + 40);
    doc.text(bid.Phone || '—', 100, supplierStartY + 40);
    doc.text(`Address:`, 300, supplierStartY + 40);
    doc.text(bid.Address || '—', 360, supplierStartY + 40);
    doc.moveDown(4);

    // Bid Items Table
    doc.fontSize(14).font('Helvetica-Bold').text('BID ITEMS', { underline: true });
    doc.moveDown(0.5);
    
    const tableTop = doc.y;
    const colPositions = [50, 130, 220, 280, 330, 380, 450];
    
    doc.fontSize(9).font('Helvetica-Bold');
    doc.text('Item #', colPositions[0], tableTop);
    doc.text('Item Code', colPositions[1], tableTop);
    doc.text('Description', colPositions[2], tableTop);
    doc.text('Unit', colPositions[3], tableTop);
    doc.text('Quantity', colPositions[4], tableTop, { width: 50, align: 'right' });
    doc.text('Unit Price', colPositions[5], tableTop, { width: 60, align: 'right' });
    doc.text('Total', colPositions[6], tableTop, { width: 60, align: 'right' });
    
    doc.moveTo(50, tableTop + 15).lineTo(545, tableTop + 15).stroke();
    
    let currentY = tableTop + 25;
    doc.fontSize(9).font('Helvetica');
    
    items.forEach((item) => {
      if (currentY > 700) {
        doc.addPage();
        currentY = 50;
      }
      
      doc.text(item.ItemNo.toString(), colPositions[0], currentY);
      doc.text(item.TenderItemID, colPositions[1], currentY, { width: 80 });
      doc.text(item.Description.substring(0, 40), colPositions[2], currentY, { width: 100 });
      doc.text(item.Unit, colPositions[3], currentY);
      doc.text(item.Quantity.toString(), colPositions[4], currentY, { width: 50, align: 'right' });
      doc.text(`GHS ${parseFloat(item.UnitPrice).toFixed(2)}`, colPositions[5], currentY, { width: 60, align: 'right' });
      doc.text(`GHS ${parseFloat(item.Total).toFixed(2)}`, colPositions[6], currentY, { width: 60, align: 'right' });
      
      currentY += 20;
    });
    
    currentY += 10;
    doc.moveTo(350, currentY - 5).lineTo(545, currentY - 5).stroke();
    doc.fontSize(12).font('Helvetica-Bold');
    doc.text('GRAND TOTAL:', 350, currentY);
    doc.text(`GHS ${parseFloat(bid.GrandTotal).toFixed(2)}`, 450, currentY, { align: 'right' });
    
    doc.moveDown(4);
    doc.fontSize(8).font('Helvetica');
    doc.text('This is a system-generated receipt. Please retain for your records.', 50, 750, { align: 'center' });
    
    doc.end();
    
  } catch (error) {
    console.error('[Download Bid PDF] Error:', error);
    res.status(500).json({ message: error.message });
  }
});


// ============================================================
// START
// ============================================================

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Health:   http://localhost:${PORT}/api/health`);
});